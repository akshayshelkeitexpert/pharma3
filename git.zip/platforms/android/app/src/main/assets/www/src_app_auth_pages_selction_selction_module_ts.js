"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth_pages_selction_selction_module_ts"],{

/***/ 3389:
/*!****************************************************************!*\
  !*** ./src/app/auth/pages/selction/selction-routing.module.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelctionPageRoutingModule": () => (/* binding */ SelctionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _selction_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./selction.page */ 5668);




const routes = [
    {
        path: '',
        component: _selction_page__WEBPACK_IMPORTED_MODULE_0__.SelctionPage
    }
];
let SelctionPageRoutingModule = class SelctionPageRoutingModule {
};
SelctionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SelctionPageRoutingModule);



/***/ }),

/***/ 1561:
/*!********************************************************!*\
  !*** ./src/app/auth/pages/selction/selction.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelctionPageModule": () => (/* binding */ SelctionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _selction_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./selction-routing.module */ 3389);
/* harmony import */ var _selction_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./selction.page */ 5668);







let SelctionPageModule = class SelctionPageModule {
};
SelctionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _selction_routing_module__WEBPACK_IMPORTED_MODULE_0__.SelctionPageRoutingModule
        ],
        declarations: [_selction_page__WEBPACK_IMPORTED_MODULE_1__.SelctionPage]
    })
], SelctionPageModule);



/***/ }),

/***/ 5668:
/*!******************************************************!*\
  !*** ./src/app/auth/pages/selction/selction.page.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelctionPage": () => (/* binding */ SelctionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _selction_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./selction.page.html?ngResource */ 9453);
/* harmony import */ var _selction_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./selction.page.scss?ngResource */ 6079);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let SelctionPage = class SelctionPage {
    constructor() { }
    ngOnInit() {
    }
};
SelctionPage.ctorParameters = () => [];
SelctionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-selction',
        template: _selction_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_selction_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SelctionPage);



/***/ }),

/***/ 6079:
/*!*******************************************************************!*\
  !*** ./src/app/auth/pages/selction/selction.page.scss?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-selction .selction-btn {\n  --background: #83C24C !important;\n  --border-radius: 83px 60px 60px 0px !important;\n  height: 54px;\n  --box-shadow: none;\n}\n::ng-deep app-selction .selction-btn1 {\n  --background: #10A8A0;\n  --border-radius: 83px 60px 60px 0px !important;\n  height: 54px;\n  --box-shadow: none;\n}\n::ng-deep app-selction .top-logo {\n  position: relative;\n}\n::ng-deep app-selction .top-logo img {\n  width: 11pc;\n}\n::ng-deep app-selction ion-row.next-btn {\n  position: relative;\n  top: 10rem;\n}\n::ng-deep app-selction .password {\n  text-decoration: none;\n}\n::ng-deep app-selction .custom-textbox {\n  font-weight: 400;\n  font-size: 14px;\n  line-height: 126.39%;\n  border-radius: 50px 60px 60px 0px;\n}\n::ng-deep app-selction .forgot-link a {\n  color: var(--ion-color-primary);\n  text-decoration: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGN0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHSTtFQUNFLGdDQUFBO0VBR0EsOENBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFKTjtBQU9JO0VBQ0UscUJBQUE7RUFDQSw4Q0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUxOO0FBUUk7RUFDRSxrQkFBQTtBQU5OO0FBU007RUFDRSxXQUFBO0FBUFI7QUFZTTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtBQVZSO0FBZ0JJO0VBQ0UscUJBQUE7QUFkTjtBQWlCSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLG9CQUFBO0VBQ0EsaUNBQUE7QUFmTjtBQW1CTTtFQUNFLCtCQUFBO0VBQ0EscUJBQUE7QUFqQlIiLCJmaWxlIjoic2VsY3Rpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIHtcclxuICBhcHAtc2VsY3Rpb24ge1xyXG5cclxuICAgIC5zZWxjdGlvbi1idG4ge1xyXG4gICAgICAtLWJhY2tncm91bmQ6ICM4M0MyNEMgIWltcG9ydGFudDtcclxuICAgICAgO1xyXG5cclxuICAgICAgLS1ib3JkZXItcmFkaXVzOiA4M3B4IDYwcHggNjBweCAwcHggIWltcG9ydGFudDtcclxuICAgICAgaGVpZ2h0OiA1NHB4O1xyXG4gICAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICB9XHJcblxyXG4gICAgLnNlbGN0aW9uLWJ0bjEge1xyXG4gICAgICAtLWJhY2tncm91bmQ6ICMxMEE4QTA7XHJcbiAgICAgIC0tYm9yZGVyLXJhZGl1czogODNweCA2MHB4IDYwcHggMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgIGhlaWdodDogNTRweDtcclxuICAgICAgLS1ib3gtc2hhZG93OiBub25lO1xyXG4gICAgfVxyXG5cclxuICAgIC50b3AtbG9nbyB7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICAgIC8vIHRvcDogNTZweDtcclxuICAgICAgaW1nIHtcclxuICAgICAgICB3aWR0aDogMTFwYztcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGlvbi1yb3cge1xyXG4gICAgICAmLm5leHQtYnRuIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOiAxMHJlbTtcclxuXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgLnBhc3N3b3JkIHtcclxuICAgICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgfVxyXG5cclxuICAgIC5jdXN0b20tdGV4dGJveCB7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDEyNi4zOSU7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwcHggNjBweCA2MHB4IDBweDtcclxuICAgIH1cclxuXHJcbiAgICAuZm9yZ290LWxpbmsge1xyXG4gICAgICBhIHtcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICB9XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 9453:
/*!*******************************************************************!*\
  !*** ./src/app/auth/pages/selction/selction.page.html?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <form>\n    <div class=\"login-screen\">\n      <div class=\"header\">\n        <ng-container>\n          <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n        </ng-container>\n      </div>\n      <div class=\"text-center top-logo ion-padding ion-margin\">\n        <ion-row class=\"ion-margin\">\n          <ion-col size=\"12\" class=\"text-center\">\n            <img src=\"assets/icon/Pharma.png\" class=\"logo\">\n          </ion-col>\n          <ion-col size=\"12\" class=\"text-center\">\n            <ion-text class=\"recover\">\n              <h1 class=\"tag\">Want to buy or sell?</h1>\n              <h7 class=\"tag2\">Buy and Sell with us</h7>\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"next-btn  \">\n          <ion-col size=\"12\">\n            <ion-button expand=\"block\" type=\"submit\" class=\"selction-btn\" routerLink=\"/auth/mapselction\">Buy Now\n            </ion-button>\n          </ion-col>\n          <ion-col size=\"12\">\n            <ion-button expand=\"block\" type=\"submit\" class=\"selction-btn1\">Sell Now\n            </ion-button>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n  </form>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_auth_pages_selction_selction_module_ts.js.map