"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth_pages_forgot-password_forgot-password_module_ts"],{

/***/ 8151:
/*!******************************************************************************!*\
  !*** ./src/app/auth/pages/forgot-password/forgot-password-routing.module.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPageRoutingModule": () => (/* binding */ ForgotPasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _forgot_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password.page */ 8567);




const routes = [
    {
        path: '',
        component: _forgot_password_page__WEBPACK_IMPORTED_MODULE_0__.ForgotPasswordPage
    }
];
let ForgotPasswordPageRoutingModule = class ForgotPasswordPageRoutingModule {
};
ForgotPasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ForgotPasswordPageRoutingModule);



/***/ }),

/***/ 9628:
/*!**********************************************************************!*\
  !*** ./src/app/auth/pages/forgot-password/forgot-password.module.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPageModule": () => (/* binding */ ForgotPasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password-routing.module */ 8151);
/* harmony import */ var _forgot_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forgot-password.page */ 8567);







let ForgotPasswordPageModule = class ForgotPasswordPageModule {
};
ForgotPasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_0__.ForgotPasswordPageRoutingModule
        ],
        declarations: [_forgot_password_page__WEBPACK_IMPORTED_MODULE_1__.ForgotPasswordPage]
    })
], ForgotPasswordPageModule);



/***/ }),

/***/ 8567:
/*!********************************************************************!*\
  !*** ./src/app/auth/pages/forgot-password/forgot-password.page.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPage": () => (/* binding */ ForgotPasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _forgot_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password.page.html?ngResource */ 9371);
/* harmony import */ var _forgot_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forgot-password.page.scss?ngResource */ 9843);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let ForgotPasswordPage = class ForgotPasswordPage {
    constructor() { }
    ngOnInit() {
    }
    prevTab() {
    }
};
ForgotPasswordPage.ctorParameters = () => [];
ForgotPasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-forgot-password',
        template: _forgot_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_forgot_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ForgotPasswordPage);



/***/ }),

/***/ 9843:
/*!*********************************************************************************!*\
  !*** ./src/app/auth/pages/forgot-password/forgot-password.page.scss?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-forgot-password .header {\n  top: 38px;\n  position: relative;\n  left: 12px;\n}\n::ng-deep app-forgot-password .logo {\n  width: 205px;\n}\n::ng-deep app-forgot-password .recover {\n  bottom: 12px;\n  position: relative;\n}\n::ng-deep app-forgot-password .recover .tag {\n  font-weight: 400;\n  font-size: 26px;\n}\n::ng-deep app-forgot-password .recover .tag2 {\n  font-size: 15px;\n}\n::ng-deep app-forgot-password ion-row .custom-textbox {\n  opacity: 0.5;\n  border: 1px solid #000000;\n  box-sizing: border-box;\n  border-radius: 60px;\n  color: #93949A;\n  padding: 7px 9px !important;\n  color: black;\n}\n::ng-deep app-forgot-password ion-row.next-btn {\n  position: relative;\n  top: 7rem;\n}\n::ng-deep app-forgot-password ion-row.forgot-btn {\n  position: relative;\n  top: 5rem;\n  text-decoration: none;\n  font-size: 20px;\n}\n::ng-deep app-forgot-password .left-icon {\n  margin-left: 10px;\n  padding: 6px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcmdvdC1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUk7RUFDRSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FBRE47QUFJSTtFQUNFLFlBQUE7QUFGTjtBQUtJO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0FBSE47QUFLTTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtBQUhSO0FBTU07RUFDRSxlQUFBO0FBSlI7QUFpQk07RUFDRSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0VBRUEsWUFBQTtBQWhCUjtBQW1CTTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtBQWpCUjtBQW9CTTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtBQWxCUjtBQXdCSTtFQUNFLGlCQUFBO0VBQ0EsWUFBQTtBQXRCTiIsImZpbGUiOiJmb3Jnb3QtcGFzc3dvcmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIHtcclxuICBhcHAtZm9yZ290LXBhc3N3b3JkIHtcclxuICAgIC5oZWFkZXIge1xyXG4gICAgICB0b3A6IDM4cHg7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgbGVmdDogMTJweDtcclxuICAgIH1cclxuXHJcbiAgICAubG9nbyB7XHJcbiAgICAgIHdpZHRoOiAyMDVweDtcclxuICAgIH1cclxuXHJcbiAgICAucmVjb3ZlciB7XHJcbiAgICAgIGJvdHRvbTogMTJweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5cclxuICAgICAgLnRhZyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgICBmb250LXNpemU6IDI2cHg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC50YWcyIHtcclxuICAgICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG5cclxuICAgIC8vIC5pbnB1dCB7XHJcbiAgICAvLyAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIC8vICAgYm90dG9tOiAxNXB4O1xyXG4gICAgLy8gfVxyXG5cclxuXHJcbiAgICBpb24tcm93IHtcclxuICAgICAgLmN1c3RvbS10ZXh0Ym94IHtcclxuICAgICAgICBvcGFjaXR5OiAwLjU7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgIzAwMDAwMDtcclxuICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDYwcHg7XHJcbiAgICAgICAgY29sb3I6ICM5Mzk0OUE7XHJcbiAgICAgICAgcGFkZGluZzogN3B4IDlweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIC8vIG1hcmdpbi1sZWZ0OiAxMnB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgY29sb3I6IGJsYWNrO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAmLm5leHQtYnRuIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOiA3cmVtO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAmLmZvcmdvdC1idG4ge1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICB0b3A6IDVyZW07XHJcbiAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5tZW51bC10ZXh0Ym94IHt9XHJcblxyXG4gICAgLmxlZnQtaWNvbiB7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gICAgICBwYWRkaW5nOiA2cHg7XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcbiAgLy8gaW9uLWZvb3RlciB7XHJcbiAgLy8gICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgLy8gICBib3R0b206IDBweDtcclxuICAvLyB9XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 9371:
/*!*********************************************************************************!*\
  !*** ./src/app/auth/pages/forgot-password/forgot-password.page.html?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <form>\n    <div>\n      <div class=\"header\">\n        <ng-container>\n          <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n        </ng-container>\n      </div>\n      <ion-row class=\"ion-margin\">\n        <ion-col size=\"12\" class=\"text-center\">\n          <img [src]=\"'assets/icon/forgot-ico.svg'\" class=\"logo\">\n        </ion-col>\n        <ion-col size=\"12\" class=\"text-center\">\n          <ion-text class=\"recover\">\n            <h1 class=\"tag\">Forgot password?</h1>\n            <h6 class=\"tag2\">Don't worry! We will heelp you to <br> recover your password</h6>\n          </ion-text>\n        </ion-col>\n      </ion-row>\n\n      <ion-row class=\"ion-margin\">\n        <ion-col size=\"12\">\n          <ion-input type=\"text\" expand=\"block\" class=\"form-control custom-textbox\" placeholder=\"User Name / Email Id\">\n            <ion-icon [src]=\"'assets/icon/email-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n          </ion-input>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"next-btn ion-margin\">\n        <ion-col size=\"12\" class=\"text-center\">\n          <ion-button expand=\"block\" type=\"submit\" class=\"custom-btn\" routerLink=\"/auth/otp\">GET OTP\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"12\" class=\"text-center forgot-link\"> <br>\n          <a href=\"javascript:void(0);\">Resend OTP</a>\n        </ion-col>\n      </ion-row>\n    </div>\n  </form>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_auth_pages_forgot-password_forgot-password_module_ts.js.map