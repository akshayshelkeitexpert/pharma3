"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth_pages_state_state_module_ts"],{

/***/ 6999:
/*!**********************************************************!*\
  !*** ./src/app/auth/pages/state/state-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StatePageRoutingModule": () => (/* binding */ StatePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _state_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./state.page */ 8604);




const routes = [
    {
        path: '',
        component: _state_page__WEBPACK_IMPORTED_MODULE_0__.StatePage
    }
];
let StatePageRoutingModule = class StatePageRoutingModule {
};
StatePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], StatePageRoutingModule);



/***/ }),

/***/ 2324:
/*!**************************************************!*\
  !*** ./src/app/auth/pages/state/state.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StatePageModule": () => (/* binding */ StatePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _state_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./state-routing.module */ 6999);
/* harmony import */ var _state_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./state.page */ 8604);







let StatePageModule = class StatePageModule {
};
StatePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _state_routing_module__WEBPACK_IMPORTED_MODULE_0__.StatePageRoutingModule
        ],
        declarations: [_state_page__WEBPACK_IMPORTED_MODULE_1__.StatePage]
    })
], StatePageModule);



/***/ }),

/***/ 8604:
/*!************************************************!*\
  !*** ./src/app/auth/pages/state/state.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StatePage": () => (/* binding */ StatePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _state_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./state.page.html?ngResource */ 964);
/* harmony import */ var _state_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./state.page.scss?ngResource */ 2438);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let StatePage = class StatePage {
    constructor() { }
    ngOnInit() {
    }
};
StatePage.ctorParameters = () => [];
StatePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-state',
        template: _state_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_state_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], StatePage);



/***/ }),

/***/ 2438:
/*!*************************************************************!*\
  !*** ./src/app/auth/pages/state/state.page.scss?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-state .top-logo {\n  position: relative;\n}\n::ng-deep app-state .top-logo img {\n  width: 11pc;\n}\n::ng-deep app-state ion-row.next-btn {\n  position: relative;\n  top: 11rem;\n}\n::ng-deep app-state .password {\n  text-decoration: none;\n}\n::ng-deep app-state .custom-textbox {\n  font-weight: 400;\n  font-size: 14px;\n  line-height: 126.39%;\n  border-radius: 50px 60px 60px 0px;\n}\n::ng-deep app-state .forgot-link a {\n  color: var(--ion-color-primary);\n  text-decoration: none;\n}\n::ng-deep app-state .recover .tag {\n  font-weight: 400;\n  font-size: 28px;\n}\n::ng-deep app-state .recover .tag2 {\n  font-size: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0YXRlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFSTtFQUNFLGtCQUFBO0FBRE47QUFJTTtFQUNFLFdBQUE7QUFGUjtBQU9NO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0FBTFI7QUFVSTtFQUNFLHFCQUFBO0FBUk47QUFXSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLG9CQUFBO0VBQ0EsaUNBQUE7QUFUTjtBQWFNO0VBQ0UsK0JBQUE7RUFDQSxxQkFBQTtBQVhSO0FBbUJNO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0FBakJSO0FBb0JNO0VBQ0UsZUFBQTtBQWxCUiIsImZpbGUiOiJzdGF0ZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6Om5nLWRlZXAge1xyXG4gIGFwcC1zdGF0ZSB7XHJcbiAgICAudG9wLWxvZ28ge1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgICAvLyB0b3A6IDU2cHg7XHJcbiAgICAgIGltZyB7XHJcbiAgICAgICAgd2lkdGg6IDExcGM7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBpb24tcm93IHtcclxuICAgICAgJi5uZXh0LWJ0biB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHRvcDogMTFyZW07XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgLnBhc3N3b3JkIHtcclxuICAgICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgfVxyXG5cclxuICAgIC5jdXN0b20tdGV4dGJveCB7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDEyNi4zOSU7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwcHggNjBweCA2MHB4IDBweDtcclxuICAgIH1cclxuXHJcbiAgICAuZm9yZ290LWxpbmsge1xyXG4gICAgICBhIHtcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5yZWNvdmVyIHtcclxuICAgICAgLy8gYm90dG9tOiAxMnB4O1xyXG4gICAgICAvLyBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgICAudGFnIHtcclxuICAgICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjhweDtcclxuICAgICAgfVxyXG5cclxuICAgICAgLnRhZzIge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGlvbi1yb3cge31cclxuXHJcbiAgfVxyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 964:
/*!*************************************************************!*\
  !*** ./src/app/auth/pages/state/state.page.html?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <form>\n    <div class=\"login-screen\">\n      <div class=\"header\">\n        <ng-container>\n          <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n        </ng-container>\n      </div>\n      <ion-row class=\"ion-margin ion-padding\">\n        <ion-col size=\"12\" class=\"text-center\">\n          <ion-text class=\"recover\">\n            <h1 class=\"tag\">Fill the Mandatory information</h1>\n            <h7 class=\"tag2\">for a personalized user experience</h7>\n          </ion-text>\n        </ion-col>\n      </ion-row>\n      <br>\n      <ion-row class=\"ion-margin\">\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\"\n            placeholder=\"Enter area, street name or pincode\">\n            <ion-icon [src]=\"'assets/icon/location-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n          </ion-input>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" [type]=\"showPsw ? 'text' : 'password'\" expand=\"block\"\n            class=\"form-control custom-textbox right-icon-available\" placeholder=\"Using GPS\">\n            <ion-icon [src]=\"'assets/icon/station-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n\n            <ion-icon *ngIf=\"showPsw==true\" (click)=\"changePassword()\" class=\"right-icon\"\n              [src]=\"'assets/icon/pass-eye-close-ico.svg'\" color=\"warning\"></ion-icon>\n            <ion-icon [src]=\"'assets/icon/pass-eye-close-ico.svg'\" (click)=\"changePassword()\" class=\"right-icon\"\n              *ngIf=\"showPsw==false\" color=\"warning\">\n            </ion-icon>\n          </ion-input>\n        </ion-col>\n      </ion-row>\n\n\n      <br>\n      <ion-row class=\"next-btn ion-padding-top ion-margin \">\n        <ion-col size=\"12\">\n          <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/assosiates\" class=\"custom-btn\">Next\n          </ion-button>\n        </ion-col>\n      </ion-row>\n      <br>\n    </div>\n  </form>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_auth_pages_state_state_module_ts.js.map