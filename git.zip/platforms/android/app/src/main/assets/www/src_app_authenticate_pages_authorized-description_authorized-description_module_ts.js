"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_authorized-description_authorized-description_module_ts"],{

/***/ 9733:
/*!****************************************************************************************************!*\
  !*** ./src/app/authenticate/pages/authorized-description/authorized-description-routing.module.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthorizedDescriptionPageRoutingModule": () => (/* binding */ AuthorizedDescriptionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _authorized_description_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./authorized-description.page */ 71);




const routes = [
    {
        path: '',
        component: _authorized_description_page__WEBPACK_IMPORTED_MODULE_0__.AuthorizedDescriptionPage
    }
];
let AuthorizedDescriptionPageRoutingModule = class AuthorizedDescriptionPageRoutingModule {
};
AuthorizedDescriptionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AuthorizedDescriptionPageRoutingModule);



/***/ }),

/***/ 5912:
/*!********************************************************************************************!*\
  !*** ./src/app/authenticate/pages/authorized-description/authorized-description.module.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthorizedDescriptionPageModule": () => (/* binding */ AuthorizedDescriptionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _authorized_description_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./authorized-description-routing.module */ 9733);
/* harmony import */ var _authorized_description_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./authorized-description.page */ 71);







let AuthorizedDescriptionPageModule = class AuthorizedDescriptionPageModule {
};
AuthorizedDescriptionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _authorized_description_routing_module__WEBPACK_IMPORTED_MODULE_0__.AuthorizedDescriptionPageRoutingModule
        ],
        declarations: [_authorized_description_page__WEBPACK_IMPORTED_MODULE_1__.AuthorizedDescriptionPage]
    })
], AuthorizedDescriptionPageModule);



/***/ }),

/***/ 71:
/*!******************************************************************************************!*\
  !*** ./src/app/authenticate/pages/authorized-description/authorized-description.page.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthorizedDescriptionPage": () => (/* binding */ AuthorizedDescriptionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _authorized_description_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./authorized-description.page.html?ngResource */ 3105);
/* harmony import */ var _authorized_description_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./authorized-description.page.scss?ngResource */ 3579);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let AuthorizedDescriptionPage = class AuthorizedDescriptionPage {
    constructor() { }
    ngOnInit() {
    }
};
AuthorizedDescriptionPage.ctorParameters = () => [];
AuthorizedDescriptionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-authorized-description',
        template: _authorized_description_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_authorized_description_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AuthorizedDescriptionPage);



/***/ }),

/***/ 3579:
/*!*******************************************************************************************************!*\
  !*** ./src/app/authenticate/pages/authorized-description/authorized-description.page.scss?ngResource ***!
  \*******************************************************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-authorized-description ion-content .custom-textarea {\n  opacity: 0.5;\n  border: 1px solid #000000;\n  box-sizing: border-box;\n  border-radius: 12px;\n  height: 131px;\n}\n::ng-deep app-authorized-description ion-content .attachment-icon {\n  width: 22px;\n  height: 24px;\n  margin-right: 9px;\n  position: relative;\n  top: 4px;\n}\n::ng-deep app-authorized-description ion-content .page-heading {\n  font-size: 28px;\n  color: #31333D;\n}\n::ng-deep app-authorized-description ion-content .custom-textbox {\n  font-weight: 400;\n  font-size: 14px;\n  line-height: 126.39%;\n  border-radius: 50px 60px 60px 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dGhvcml6ZWQtZGVzY3JpcHRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdNO0VBQ0UsWUFBQTtFQUNBLHlCQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7QUFGUjtBQUtNO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtBQUhSO0FBTU07RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQUpSO0FBT007RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLGlDQUFBO0FBTFIiLCJmaWxlIjoiYXV0aG9yaXplZC1kZXNjcmlwdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6Om5nLWRlZXAge1xyXG4gIGFwcC1hdXRob3JpemVkLWRlc2NyaXB0aW9uIHtcclxuICAgIGlvbi1jb250ZW50IHtcclxuICAgICAgLmN1c3RvbS10ZXh0YXJlYSB7XHJcbiAgICAgICAgb3BhY2l0eTogMC41O1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICMwMDAwMDA7XHJcbiAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxMnB4O1xyXG4gICAgICAgIGhlaWdodDogMTMxcHg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5hdHRhY2htZW50LWljb24ge1xyXG4gICAgICAgIHdpZHRoOiAyMnB4O1xyXG4gICAgICAgIGhlaWdodDogMjRweDtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IDlweDtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOiA0cHg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5wYWdlLWhlYWRpbmcge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjhweDtcclxuICAgICAgICBjb2xvcjogIzMxMzMzRDtcclxuICAgICAgfVxyXG5cclxuICAgICAgLmN1c3RvbS10ZXh0Ym94IHtcclxuICAgICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICBsaW5lLWhlaWdodDogMTI2LjM5JTtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1MHB4IDYwcHggNjBweCAwcHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgfVxyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 3105:
/*!*******************************************************************************************************!*\
  !*** ./src/app/authenticate/pages/authorized-description/authorized-description.page.html?ngResource ***!
  \*******************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-padding-start ion-padding-top ion-padding-end\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <form>\n    <ion-row>\n      <ion-col size=\"12\" class=\"text-center \">\n        <ion-text class=\"recover\">\n          <p class=\"page-heading ion-no-margin\">Your Authorized Vendor</p>\n        </ion-text>\n      </ion-col>\n\n      <ion-col size=\"12\" class=\"ion-margin-top ion-padding-top\">\n        <ion-checkbox class=\"checkbox-stay-login\"></ion-checkbox> &nbsp;&nbsp;\n        <ion-label>Yes! I’m Authorized</ion-label>\n      </ion-col>\n\n      <ion-col size=\"12\" class=\"ion-margin-top\">\n        <ion-textarea placeholder=\"Type here...\" class=\"form-control custom-textarea\">\n        </ion-textarea>\n      </ion-col>\n\n      <ion-col size=\"12\" class=\"ion-margin-top\">\n        <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox ion-padding\"\n          placeholder=\"Company Authorisation Name\"></ion-input>\n      </ion-col>\n\n      <ion-col size=\"12\" class=\"text-center ion-margin-top ion-padding-top\">\n        <img [src]=\"'assets/icon/upload-img-ico.svg'\" class=\"logo\">\n      </ion-col>\n\n      <ion-col size=\"12\" class=\"text-center\">\n        <ion-icon [src]=\"'assets/icon/upload-doc-ico.svg'\" class=\"attachment-icon\"></ion-icon>Upload related documents\n        <br>\n        <a href=\"javascript:void(0);\">UPLOAD</a>\n      </ion-col>\n\n    </ion-row>\n\n  </form>\n</ion-content>\n\n<ion-footer class=\"ion-padding-bottom\">\n  <ion-toolbar class=\"ion-padding-bottom\">\n    <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/assosiates\" class=\"custom-btn\">SUBMIT\n    </ion-button>\n  </ion-toolbar>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_authorized-description_authorized-description_module_ts.js.map