"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_search_search_module_ts"],{

/***/ 7980:
/*!********************************************************************!*\
  !*** ./src/app/authenticate/pages/search/search-routing.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchPageRoutingModule": () => (/* binding */ SearchPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _search_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./search.page */ 2900);




const routes = [
    {
        path: '',
        component: _search_page__WEBPACK_IMPORTED_MODULE_0__.SearchPage
    }
];
let SearchPageRoutingModule = class SearchPageRoutingModule {
};
SearchPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SearchPageRoutingModule);



/***/ }),

/***/ 38:
/*!************************************************************!*\
  !*** ./src/app/authenticate/pages/search/search.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchPageModule": () => (/* binding */ SearchPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _search_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./search-routing.module */ 7980);
/* harmony import */ var _search_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./search.page */ 2900);







let SearchPageModule = class SearchPageModule {
};
SearchPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _search_routing_module__WEBPACK_IMPORTED_MODULE_0__.SearchPageRoutingModule
        ],
        declarations: [_search_page__WEBPACK_IMPORTED_MODULE_1__.SearchPage]
    })
], SearchPageModule);



/***/ }),

/***/ 2900:
/*!**********************************************************!*\
  !*** ./src/app/authenticate/pages/search/search.page.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchPage": () => (/* binding */ SearchPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _search_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./search.page.html?ngResource */ 3406);
/* harmony import */ var _search_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./search.page.scss?ngResource */ 2920);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let SearchPage = class SearchPage {
    constructor() { }
    ngOnInit() {
    }
};
SearchPage.ctorParameters = () => [];
SearchPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-search',
        template: _search_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_search_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SearchPage);



/***/ }),

/***/ 2920:
/*!***********************************************************************!*\
  !*** ./src/app/authenticate/pages/search/search.page.scss?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-search .header {\n  top: 38px;\n  position: relative;\n  left: 12px;\n}\n::ng-deep app-search .logo {\n  position: relative;\n  top: 47px;\n}\n::ng-deep app-search .recover {\n  bottom: 12px;\n  position: relative;\n}\n::ng-deep app-search .recover .tag {\n  font-weight: 400;\n  font-size: 27px;\n}\n::ng-deep app-search .recover .tag2 {\n  font-size: 16px;\n}\n::ng-deep app-search ion-row .custom-textbox {\n  opacity: 0.5;\n  border: 1px solid #000000;\n  box-sizing: border-box;\n  border-radius: 60px;\n  color: #93949A;\n  padding: 7px 9px !important;\n  color: black;\n}\n::ng-deep app-search ion-row.next-btn {\n  position: relative;\n  top: 13rem;\n}\n::ng-deep app-search ion-row.forgot-btn {\n  position: relative;\n  top: 5rem;\n  text-decoration: none;\n  font-size: 20px;\n}\n::ng-deep app-search .left-icon {\n  margin-left: 10px;\n  padding: 6px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlYXJjaC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUk7RUFDRSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FBRE47QUFJSTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtBQUZOO0FBS0k7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7QUFITjtBQUtNO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0FBSFI7QUFNTTtFQUNFLGVBQUE7QUFKUjtBQWlCTTtFQUNFLFlBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7RUFFQSxZQUFBO0FBaEJSO0FBbUJNO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0FBakJSO0FBb0JNO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0FBbEJSO0FBd0JJO0VBQ0UsaUJBQUE7RUFDQSxZQUFBO0FBdEJOIiwiZmlsZSI6InNlYXJjaC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6Om5nLWRlZXAge1xyXG4gIGFwcC1zZWFyY2gge1xyXG4gICAgLmhlYWRlciB7XHJcbiAgICAgIHRvcDogMzhweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICBsZWZ0OiAxMnB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5sb2dvIHtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICB0b3A6IDQ3cHg7XHJcbiAgICB9XHJcblxyXG4gICAgLnJlY292ZXIge1xyXG4gICAgICBib3R0b206IDEycHg7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICAgIC50YWcge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgICAgZm9udC1zaXplOiAyN3B4O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAudGFnMiB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuXHJcbiAgICAvLyAuaW5wdXQge1xyXG4gICAgLy8gICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAvLyAgIGJvdHRvbTogMTVweDtcclxuICAgIC8vIH1cclxuXHJcblxyXG4gICAgaW9uLXJvdyB7XHJcbiAgICAgIC5jdXN0b20tdGV4dGJveCB7XHJcbiAgICAgICAgb3BhY2l0eTogMC41O1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICMwMDAwMDA7XHJcbiAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2MHB4O1xyXG4gICAgICAgIGNvbG9yOiAjOTM5NDlBO1xyXG4gICAgICAgIHBhZGRpbmc6IDdweCA5cHggIWltcG9ydGFudDtcclxuICAgICAgICAvLyBtYXJnaW4tbGVmdDogMTJweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIGNvbG9yOiBibGFjaztcclxuICAgICAgfVxyXG5cclxuICAgICAgJi5uZXh0LWJ0biB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHRvcDogMTNyZW07XHJcbiAgICAgIH1cclxuXHJcbiAgICAgICYuZm9yZ290LWJ0biB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHRvcDogNXJlbTtcclxuICAgICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLm1lbnVsLXRleHRib3gge31cclxuXHJcbiAgICAubGVmdC1pY29uIHtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICAgIHBhZGRpbmc6IDZweDtcclxuICAgIH1cclxuXHJcbiAgfVxyXG5cclxufVxyXG4iXX0= */";

/***/ }),

/***/ 3406:
/*!***********************************************************************!*\
  !*** ./src/app/authenticate/pages/search/search.page.html?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <form>\n    <div class=\"login-screen\">\n      <div class=\"header\">\n        <ng-container>\n          <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n        </ng-container>\n      </div>\n      <ion-row class=\"ion-margin ion-padding logo\">\n        <ion-col size=\"12\" class=\"text-center\">\n          <ion-text class=\"recover\">\n            <h1 class=\"tag\">What are you searching for?</h1>\n            <h6 class=\"tag2\">for a personalized user experience</h6>\n          </ion-text>\n        </ion-col>\n      </ion-row>\n\n      <ion-row class=\"ion-margin ion-padding-top \">\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\"\n            placeholder=\"Enter product name you want to buy\">\n            <ion-icon [src]=\"'assets/icon/location-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n          </ion-input>\n        </ion-col>\n\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\"\n            placeholder=\"Manufacturer Name\">\n            <ion-icon [src]=\"'assets/icon/location-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n          </ion-input>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\"\n            placeholder=\"Avg. Order Value \">\n            <ion-icon [src]=\"'assets/icon/location-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n          </ion-input>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\"\n            placeholder=\"Unit\">\n            <ion-icon [src]=\"'assets/icon/location-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n          </ion-input>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\"\n            placeholder=\"Quantity\">\n            <ion-icon [src]=\"'assets/icon/location-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n          </ion-input>\n        </ion-col>\n      </ion-row>\n\n\n      <br>\n      <ion-row class=\"next-btn ion-padding-top ion-margin \">\n        <ion-col size=\"12\">\n          <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/assosiates\" class=\"custom-btn\">Next\n          </ion-button>\n        </ion-col>\n      </ion-row>\n      <br>\n    </div>\n  </form>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_search_search_module_ts.js.map