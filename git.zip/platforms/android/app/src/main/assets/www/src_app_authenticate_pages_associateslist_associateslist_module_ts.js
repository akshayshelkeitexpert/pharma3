"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_associateslist_associateslist_module_ts"],{

/***/ 4899:
/*!************************************************************************************!*\
  !*** ./src/app/authenticate/pages/associateslist/associateslist-routing.module.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AssociateslistPageRoutingModule": () => (/* binding */ AssociateslistPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _associateslist_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./associateslist.page */ 7775);




const routes = [
    {
        path: '',
        component: _associateslist_page__WEBPACK_IMPORTED_MODULE_0__.AssociateslistPage
    }
];
let AssociateslistPageRoutingModule = class AssociateslistPageRoutingModule {
};
AssociateslistPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AssociateslistPageRoutingModule);



/***/ }),

/***/ 5038:
/*!****************************************************************************!*\
  !*** ./src/app/authenticate/pages/associateslist/associateslist.module.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AssociateslistPageModule": () => (/* binding */ AssociateslistPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _associateslist_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./associateslist-routing.module */ 4899);
/* harmony import */ var _associateslist_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./associateslist.page */ 7775);







let AssociateslistPageModule = class AssociateslistPageModule {
};
AssociateslistPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _associateslist_routing_module__WEBPACK_IMPORTED_MODULE_0__.AssociateslistPageRoutingModule
        ],
        declarations: [_associateslist_page__WEBPACK_IMPORTED_MODULE_1__.AssociateslistPage]
    })
], AssociateslistPageModule);



/***/ }),

/***/ 7775:
/*!**************************************************************************!*\
  !*** ./src/app/authenticate/pages/associateslist/associateslist.page.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AssociateslistPage": () => (/* binding */ AssociateslistPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _associateslist_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./associateslist.page.html?ngResource */ 2180);
/* harmony import */ var _associateslist_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./associateslist.page.scss?ngResource */ 2965);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let AssociateslistPage = class AssociateslistPage {
    constructor() { }
    ngOnInit() {
    }
};
AssociateslistPage.ctorParameters = () => [];
AssociateslistPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-associateslist',
        template: _associateslist_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_associateslist_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AssociateslistPage);



/***/ }),

/***/ 2965:
/*!***************************************************************************************!*\
  !*** ./src/app/authenticate/pages/associateslist/associateslist.page.scss?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-associateslist ion-list hr {\n  background: #CACFE3;\n  margin: 0px 20px;\n  height: 0.4px;\n}\n::ng-deep app-associateslist ion-list .profileName {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 126.39%;\n  color: #31333D;\n  margin-left: 12px;\n}\n::ng-deep app-associateslist ion-list ion-list-header h3 {\n  color: #6B6B6B;\n  font-weight: bold;\n}\n::ng-deep app-associateslist ion-list ion-item {\n  --border-color: #fff;\n}\n::ng-deep app-associateslist ion-list ion-item ion-avatar {\n  margin-right: 10px;\n}\n::ng-deep app-associateslist ion-list ion-item ion-label h4 {\n  font-weight: bold;\n  color: #6B6B6B;\n}\n::ng-deep app-associateslist ion-list ion-item ion-label p {\n  margin: 0;\n}\n::ng-deep app-associateslist .member-list ion-avatar {\n  background: #838BB2;\n  text-align: center;\n  font-weight: bold;\n}\n::ng-deep app-associateslist .member-list ion-avatar p {\n  margin: 0;\n  margin-top: 4px;\n  color: #fff;\n}\n::ng-deep app-associateslist .member-list .customlist {\n  background: #CACFE3;\n  height: 54px;\n  width: 54px;\n}\n::ng-deep app-associateslist span {\n  background: #EFF1F7;\n  margin-left: 50px;\n  border-radius: 12px;\n  font-size: 16px;\n  padding: 5px;\n  position: relative;\n}\n::ng-deep app-associateslist ion-row.next-btn {\n  position: relative;\n  top: 30rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc29jaWF0ZXNsaXN0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHTTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0FBRlI7QUFLTTtFQUNFLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQUhSO0FBU1E7RUFDRSxjQUFBO0VBQ0EsaUJBQUE7QUFQVjtBQVdNO0VBQ0Usb0JBQUE7QUFUUjtBQVdRO0VBQ0Usa0JBQUE7QUFUVjtBQWFVO0VBQ0UsaUJBQUE7RUFDQSxjQUFBO0FBWFo7QUFjVTtFQUNFLFNBQUE7QUFaWjtBQW1CTTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQWpCUjtBQW1CUTtFQUNFLFNBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtBQWpCVjtBQXFCTTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFuQlI7QUF1Qkk7RUFDRSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBckJOO0FBeUJNO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0FBdkJSIiwiZmlsZSI6ImFzc29jaWF0ZXNsaXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjo6bmctZGVlcCB7XHJcbiAgYXBwLWFzc29jaWF0ZXNsaXN0IHtcclxuICAgIGlvbi1saXN0IHtcclxuICAgICAgaHIge1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNDQUNGRTM7XHJcbiAgICAgICAgbWFyZ2luOiAwcHggMjBweDtcclxuICAgICAgICBoZWlnaHQ6IDAuNHB4O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAucHJvZmlsZU5hbWUge1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcclxuICAgICAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDEyNi4zOSU7XHJcbiAgICAgICAgY29sb3I6ICMzMTMzM0Q7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDEycHg7XHJcblxyXG4gICAgICB9XHJcblxyXG4gICAgICBpb24tbGlzdC1oZWFkZXIge1xyXG5cclxuICAgICAgICBoMyB7XHJcbiAgICAgICAgICBjb2xvcjogIzZCNkI2QjtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgaW9uLWl0ZW0ge1xyXG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiAjZmZmO1xyXG5cclxuICAgICAgICBpb24tYXZhdGFyIHtcclxuICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICBoNCB7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgICAgICBjb2xvcjogIzZCNkI2QjtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBwIHtcclxuICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5tZW1iZXItbGlzdCB7XHJcbiAgICAgIGlvbi1hdmF0YXIge1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICM4MzhCQjI7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG5cclxuICAgICAgICBwIHtcclxuICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgIG1hcmdpbi10b3A6IDRweDtcclxuICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgLmN1c3RvbWxpc3Qge1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNDQUNGRTM7XHJcbiAgICAgICAgaGVpZ2h0OiA1NHB4O1xyXG4gICAgICAgIHdpZHRoOiA1NHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc3BhbiB7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNFRkYxRjc7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiA1MHB4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAxMnB4O1xyXG4gICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgIHBhZGRpbmc6IDVweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgfVxyXG5cclxuICAgIGlvbi1yb3cge1xyXG4gICAgICAmLm5leHQtYnRuIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOiAzMHJlbTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0= */";

/***/ }),

/***/ 2180:
/*!***************************************************************************************!*\
  !*** ./src/app/authenticate/pages/associateslist/associateslist.page.html?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-padding-start ion-padding-top ion-padding-end\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n    </ion-buttons>\n    <ion-title>Associates</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-list class=\"member-list\">\n    <ion-item class=\"ion-margin\">\n      <ion-avatar class=\"customlist\">\n\n      </ion-avatar>\n      <ion-label>\n        <h3 class=\"profileName\">Amit Pramanik</h3>\n      </ion-label>\n    </ion-item>\n    <ion-item class=\"ion-margin\">\n      <ion-avatar class=\"customlist\">\n\n      </ion-avatar>\n      <ion-label>\n        <h3 class=\"profileName\">Amit Pramanik</h3>\n      </ion-label>\n    </ion-item>\n  </ion-list>\n  <ion-row class=\"next-btn ion-padding-top ion-margin \">\n    <ion-col size=\"12\">\n      <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/assosiates\" class=\"custom-btn\">Add Associates\n      </ion-button>\n    </ion-col>\n  </ion-row>\n\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_associateslist_associateslist_module_ts.js.map