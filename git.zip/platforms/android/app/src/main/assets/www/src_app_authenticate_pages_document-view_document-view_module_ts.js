"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_document-view_document-view_module_ts"],{

/***/ 4417:
/*!**********************************************************************************!*\
  !*** ./src/app/authenticate/pages/document-view/document-view-routing.module.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DocumentViewPageRoutingModule": () => (/* binding */ DocumentViewPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _document_view_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./document-view.page */ 1136);




const routes = [
    {
        path: '',
        component: _document_view_page__WEBPACK_IMPORTED_MODULE_0__.DocumentViewPage
    }
];
let DocumentViewPageRoutingModule = class DocumentViewPageRoutingModule {
};
DocumentViewPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DocumentViewPageRoutingModule);



/***/ }),

/***/ 5513:
/*!**************************************************************************!*\
  !*** ./src/app/authenticate/pages/document-view/document-view.module.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DocumentViewPageModule": () => (/* binding */ DocumentViewPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _document_view_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./document-view-routing.module */ 4417);
/* harmony import */ var _document_view_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./document-view.page */ 1136);







let DocumentViewPageModule = class DocumentViewPageModule {
};
DocumentViewPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _document_view_routing_module__WEBPACK_IMPORTED_MODULE_0__.DocumentViewPageRoutingModule
        ],
        declarations: [_document_view_page__WEBPACK_IMPORTED_MODULE_1__.DocumentViewPage]
    })
], DocumentViewPageModule);



/***/ }),

/***/ 1136:
/*!************************************************************************!*\
  !*** ./src/app/authenticate/pages/document-view/document-view.page.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DocumentViewPage": () => (/* binding */ DocumentViewPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _document_view_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./document-view.page.html?ngResource */ 2179);
/* harmony import */ var _document_view_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./document-view.page.scss?ngResource */ 6302);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let DocumentViewPage = class DocumentViewPage {
    constructor() { }
    ngOnInit() {
    }
};
DocumentViewPage.ctorParameters = () => [];
DocumentViewPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-document-view',
        template: _document_view_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_document_view_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DocumentViewPage);



/***/ }),

/***/ 6302:
/*!*************************************************************************************!*\
  !*** ./src/app/authenticate/pages/document-view/document-view.page.scss?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-document-view ion-content .custome-text {\n  background: #F6F8FA;\n  border-radius: 31px 60px 60px 0px;\n}\n::ng-deep app-document-view ion-content .approval p {\n  display: inline-flex;\n  justify-content: center;\n  align-items: center;\n}\n::ng-deep app-document-view ion-content .approval .img-delete {\n  position: relative;\n  left: 2pc;\n}\n::ng-deep app-document-view ion-content .title1 {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 154.5%;\n  /* identical to box height, or 25px */\n  color: #000000;\n}\n::ng-deep app-document-view ion-content .title2 {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 14px;\n  line-height: 126.39%;\n  /* identical to box height, or 18px */\n  color: #93949A;\n}\n::ng-deep app-document-view ion-content .tag {\n  background: #83C24C;\n  border-radius: 60px;\n  height: 31px;\n  width: 88px;\n  text-align: center;\n  color: white;\n}\n::ng-deep app-document-view ion-content .tag2 {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 154.5%;\n  color: #000000;\n  opacity: 0.5;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRvY3VtZW50LXZpZXcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdNO0VBQ0UsbUJBQUE7RUFDQSxpQ0FBQTtBQUZSO0FBT1E7RUFDRSxvQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFMVjtBQVFRO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0FBTlY7QUFVTTtFQUNFLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLHFDQUFBO0VBR0EsY0FBQTtBQVZSO0FBY007RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esb0JBQUE7RUFDQSxxQ0FBQTtFQUdBLGNBQUE7QUFkUjtBQWtCTTtFQUNFLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQWhCUjtBQW1CTTtFQUNFLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FBakJSIiwiZmlsZSI6ImRvY3VtZW50LXZpZXcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIHtcclxuICBhcHAtZG9jdW1lbnQtdmlldyB7XHJcbiAgICBpb24tY29udGVudCB7XHJcbiAgICAgIC5jdXN0b21lLXRleHQge1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNGNkY4RkE7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMzFweCA2MHB4IDYwcHggMHB4O1xyXG4gICAgICAgIC8vIGhlaWdodDogNDI0cHhcclxuICAgICAgfVxyXG5cclxuICAgICAgLmFwcHJvdmFsIHtcclxuICAgICAgICBwIHtcclxuICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmltZy1kZWxldGUge1xyXG4gICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgbGVmdDogMnBjO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgLnRpdGxlMSB7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xyXG4gICAgICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICBsaW5lLWhlaWdodDogMTU0LjUlO1xyXG4gICAgICAgIC8qIGlkZW50aWNhbCB0byBib3ggaGVpZ2h0LCBvciAyNXB4ICovXHJcblxyXG5cclxuICAgICAgICBjb2xvcjogIzAwMDAwMDtcclxuXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC50aXRsZTIge1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcclxuICAgICAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDEyNi4zOSU7XHJcbiAgICAgICAgLyogaWRlbnRpY2FsIHRvIGJveCBoZWlnaHQsIG9yIDE4cHggKi9cclxuXHJcblxyXG4gICAgICAgIGNvbG9yOiAjOTM5NDlBO1xyXG5cclxuICAgICAgfVxyXG5cclxuICAgICAgLnRhZyB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogIzgzQzI0QztcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2MHB4O1xyXG4gICAgICAgIGhlaWdodDogMzFweDtcclxuICAgICAgICB3aWR0aDogODhweDtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAudGFnMiB7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xyXG4gICAgICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICBsaW5lLWhlaWdodDogMTU0LjUlO1xyXG4gICAgICAgIGNvbG9yOiAjMDAwMDAwO1xyXG4gICAgICAgIG9wYWNpdHk6IDAuNTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0= */";

/***/ }),

/***/ 2179:
/*!*************************************************************************************!*\
  !*** ./src/app/authenticate/pages/document-view/document-view.page.html?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-padding-start ion-padding-top ion-padding-end\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n    </ion-buttons>\n    <ion-title>Authorized Vendor</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ng-container *ngFor=\"let i of [1,2,3,4]\">\n    <ion-row class=\"ion-margin custome-text ion-padding\">\n      <ion-col size=\"8\">\n        <img [src]=\"'assets/icon/document-view-ico.svg'\" class=\"logo\">\n        <p class=\"title1 ion-no-margin\">Company Name:</p>\n        <p class=\"title2 ion-no-margin\">ABCD Company Private Limited</p>\n      </ion-col>\n      <ion-col size=\"4\" class=\"approval\">\n        <p class=\"ion-no-margin\">Status: </p> <br> <br>\n        <p class=\"ion-no-margin tag\">Approved</p> <br> <br>\n        <p class=\"ion-no-margin img-delete\"><img [src]=\"'assets/icon/delete-ico.svg'\" class=\"logo text-center\"></p>\n      </ion-col>\n      <ion-col size=\"12\" class=\"ion-margin-top\">\n        <p class=\"tag2 ion-no-margin\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper gravida et\n          sit\n          est,\n          pellentesque interdum\n          nisi, luctus feugiat. Sit luctus elementum magna arcu elementum at at. Integer odio turpis mi in dictum.\n          Pellentesque ut aenean lobortis magna lobortis lorem nec nunc. </p>\n      </ion-col>\n    </ion-row>\n  </ng-container>\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_document-view_document-view_module_ts.js.map