"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_assosiates_assosiates_module_ts"],{

/***/ 4230:
/*!****************************************************************************!*\
  !*** ./src/app/authenticate/pages/assosiates/assosiates-routing.module.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AssosiatesPageRoutingModule": () => (/* binding */ AssosiatesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _assosiates_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./assosiates.page */ 3196);




const routes = [
    {
        path: '',
        component: _assosiates_page__WEBPACK_IMPORTED_MODULE_0__.AssosiatesPage
    }
];
let AssosiatesPageRoutingModule = class AssosiatesPageRoutingModule {
};
AssosiatesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AssosiatesPageRoutingModule);



/***/ }),

/***/ 8942:
/*!********************************************************************!*\
  !*** ./src/app/authenticate/pages/assosiates/assosiates.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AssosiatesPageModule": () => (/* binding */ AssosiatesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _assosiates_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./assosiates-routing.module */ 4230);
/* harmony import */ var _assosiates_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./assosiates.page */ 3196);







let AssosiatesPageModule = class AssosiatesPageModule {
};
AssosiatesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _assosiates_routing_module__WEBPACK_IMPORTED_MODULE_0__.AssosiatesPageRoutingModule
        ],
        declarations: [_assosiates_page__WEBPACK_IMPORTED_MODULE_1__.AssosiatesPage]
    })
], AssosiatesPageModule);



/***/ }),

/***/ 3196:
/*!******************************************************************!*\
  !*** ./src/app/authenticate/pages/assosiates/assosiates.page.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AssosiatesPage": () => (/* binding */ AssosiatesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _assosiates_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./assosiates.page.html?ngResource */ 193);
/* harmony import */ var _assosiates_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./assosiates.page.scss?ngResource */ 6887);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let AssosiatesPage = class AssosiatesPage {
    constructor() { }
    ngOnInit() {
    }
};
AssosiatesPage.ctorParameters = () => [];
AssosiatesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-assosiates',
        template: _assosiates_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_assosiates_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AssosiatesPage);



/***/ }),

/***/ 6887:
/*!*******************************************************************************!*\
  !*** ./src/app/authenticate/pages/assosiates/assosiates.page.scss?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-assosiates .header {\n  top: 38px;\n  position: relative;\n  left: 12px;\n}\n::ng-deep app-assosiates .logo {\n  width: 205px;\n}\n::ng-deep app-assosiates .recover {\n  bottom: -14px;\n  position: relative;\n}\n::ng-deep app-assosiates .recover .tag {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 28px;\n  line-height: 126.39%;\n  /* or 35px */\n  color: #31333D;\n}\n::ng-deep app-assosiates .recover .tag2 {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 126.39%;\n  /* or 20px */\n  text-align: center;\n  color: #31333D;\n}\n::ng-deep app-assosiates ion-row .custom-textbox {\n  opacity: 0.5;\n  border: 1px solid #000000;\n  box-sizing: border-box;\n  border-radius: 60px 56px 44px 0px;\n}\n::ng-deep app-assosiates ion-row.next-btn {\n  position: relative;\n  top: 24rem;\n}\n::ng-deep app-assosiates ion-row.forgot-btn {\n  position: relative;\n  top: 5rem;\n  text-decoration: none;\n  font-size: 20px;\n}\n::ng-deep app-assosiates .left-icon {\n  margin-left: 10px;\n  padding: 6px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc29zaWF0ZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQ0UsU0FBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtBQUROO0FBSUk7RUFDRSxZQUFBO0FBRk47QUFLSTtFQUNFLGFBQUE7RUFDQSxrQkFBQTtBQUhOO0FBS007RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0VBR0EsY0FBQTtBQUxSO0FBUU07RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0VBRUEsa0JBQUE7RUFFQSxjQUFBO0FBUlI7QUFzQk07RUFDRSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtFQUNBLGlDQUFBO0FBcEJSO0FBd0JNO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0FBdEJSO0FBeUJNO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0FBdkJSO0FBNkJJO0VBQ0UsaUJBQUE7RUFDQSxZQUFBO0FBM0JOIiwiZmlsZSI6ImFzc29zaWF0ZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIHtcclxuICBhcHAtYXNzb3NpYXRlcyB7XHJcbiAgICAuaGVhZGVyIHtcclxuICAgICAgdG9wOiAzOHB4O1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIGxlZnQ6IDEycHg7XHJcbiAgICB9XHJcblxyXG4gICAgLmxvZ28ge1xyXG4gICAgICB3aWR0aDogMjA1cHg7XHJcbiAgICB9XHJcblxyXG4gICAgLnJlY292ZXIge1xyXG4gICAgICBib3R0b206IC0xNHB4O1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgICAudGFnIHtcclxuICAgICAgICBmb250LWZhbWlseTogJ1JvYm90byc7XHJcbiAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgICAgZm9udC1zaXplOiAyOHB4O1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxMjYuMzklO1xyXG4gICAgICAgIC8qIG9yIDM1cHggKi9cclxuXHJcblxyXG4gICAgICAgIGNvbG9yOiAjMzEzMzNEO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAudGFnMiB7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xyXG4gICAgICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICBsaW5lLWhlaWdodDogMTI2LjM5JTtcclxuICAgICAgICAvKiBvciAyMHB4ICovXHJcblxyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbiAgICAgICAgY29sb3I6ICMzMTMzM0Q7XHJcblxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuXHJcbiAgICAvLyAuaW5wdXQge1xyXG4gICAgLy8gICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAvLyAgIGJvdHRvbTogMTVweDtcclxuICAgIC8vIH1cclxuXHJcblxyXG4gICAgaW9uLXJvdyB7XHJcbiAgICAgIC5jdXN0b20tdGV4dGJveCB7XHJcbiAgICAgICAgb3BhY2l0eTogMC41O1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICMwMDAwMDA7XHJcbiAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2MHB4IDU2cHggNDRweCAwcHg7XHJcblxyXG4gICAgICB9XHJcblxyXG4gICAgICAmLm5leHQtYnRuIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOiAyNHJlbTtcclxuICAgICAgfVxyXG5cclxuICAgICAgJi5mb3Jnb3QtYnRuIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOiA1cmVtO1xyXG4gICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAubWVudWwtdGV4dGJveCB7fVxyXG5cclxuICAgIC5sZWZ0LWljb24ge1xyXG4gICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgcGFkZGluZzogNnB4O1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 193:
/*!*******************************************************************************!*\
  !*** ./src/app/authenticate/pages/assosiates/assosiates.page.html?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <form>\n    <div class=\"login-screen\">\n      <div class=\"header\">\n        <ng-container>\n          <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n        </ng-container>\n      </div>\n      <ion-row class=\"ion-margin ion-padding\">\n        <ion-col size=\"12\" class=\"text-center\">\n          <ion-text class=\"recover\">\n            <h1 class=\"tag\">Add your Assosiates</h1>\n            <h7 class=\"tag2\">for a personalized user experience</h7>\n          </ion-text>\n        </ion-col>\n      </ion-row>\n      <br>\n      <ion-row class=\"ion-margin\">\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox ion-padding\"\n            placeholder=\"Please Enter assosiate’s UID\">\n\n          </ion-input>\n        </ion-col>\n      </ion-row>\n\n\n      <br>\n      <ion-row class=\"next-btn ion-padding-top ion-margin \">\n        <ion-col size=\"12\">\n          <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/assosiates\" class=\"custom-btn\">ADD\n          </ion-button>\n        </ion-col>\n      </ion-row>\n      <br>\n    </div>\n  </form>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_assosiates_assosiates_module_ts.js.map