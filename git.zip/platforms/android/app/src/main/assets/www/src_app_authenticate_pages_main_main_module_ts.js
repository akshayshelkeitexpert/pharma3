"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_main_main_module_ts"],{

/***/ 7993:
/*!****************************************************************!*\
  !*** ./src/app/authenticate/pages/main/main-routing.module.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainPageRoutingModule": () => (/* binding */ MainPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _main_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main.page */ 3212);




const routes = [
    {
        path: '',
        component: _main_page__WEBPACK_IMPORTED_MODULE_0__.MainPage,
        children: [
            {
                path: 'notification',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_notification_notification_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../notification/notification.module */ 1496)).then(m => m.NotificationPageModule)
            },
            {
                path: '',
                redirectTo: 'replyquotation',
                pathMatch: 'full'
            },
            {
                path: 'accountsetting',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_account-setting_account-setting_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../account-setting/account-setting.module */ 4782)).then(m => m.AccountSettingPageModule)
            },
            {
                path: 'search',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_search_search_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../search/search.module */ 38)).then(m => m.SearchPageModule)
            },
            {
                path: 'authorizedvendor',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_authorized-vendor_authorized-vendor_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../authorized-vendor/authorized-vendor.module */ 3060)).then(m => m.AuthorizedVendorPageModule)
            },
            {
                path: 'offers',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_offers_offers_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../offers/offers.module */ 5853)).then(m => m.OffersPageModule)
            },
            {
                path: 'associateslist',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_associateslist_associateslist_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../associateslist/associateslist.module */ 5038)).then(m => m.AssociateslistPageModule)
            },
            {
                path: 'associatesDetails',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_associates-details_associates-details_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../associates-details/associates-details.module */ 4535)).then(m => m.AssociatesDetailsPageModule)
            },
            {
                path: 'associates',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_assosiates_assosiates_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../assosiates/assosiates.module */ 8942)).then(m => m.AssosiatesPageModule)
            },
            {
                path: 'comments',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_comments_comments_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../comments/comments.module */ 1875)).then(m => m.CommentsPageModule)
            },
            {
                path: 'offersone',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_offersone_offersone_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../offersone/offersone.module */ 3548)).then(m => m.OffersonePageModule)
            },
            {
                path: 'authdescription',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_authorized-description_authorized-description_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../authorized-description/authorized-description.module */ 5912)).then(m => m.AuthorizedDescriptionPageModule)
            },
            {
                path: 'documentview',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_document-view_document-view_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../document-view/document-view.module */ 5513)).then(m => m.DocumentViewPageModule)
            },
            {
                path: 'quotenotification',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_quote-notification_quote-notification_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../quote-notification/quote-notification.module */ 2706)).then(m => m.QuoteNotificationPageModule)
            },
            {
                path: 'quotedetails',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_quote-details_quote-details_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../quote-details/quote-details.module */ 1804)).then(m => m.QuoteDetailsPageModule)
            },
            {
                path: 'replyquotation',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_reply-quotation_reply-quotation_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../reply-quotation/reply-quotation.module */ 6152)).then(m => m.ReplyQuotationPageModule)
            },
        ]
    }
];
let MainPageRoutingModule = class MainPageRoutingModule {
};
MainPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MainPageRoutingModule);



/***/ }),

/***/ 8591:
/*!********************************************************!*\
  !*** ./src/app/authenticate/pages/main/main.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainPageModule": () => (/* binding */ MainPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _main_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main-routing.module */ 7993);
/* harmony import */ var _main_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./main.page */ 3212);







let MainPageModule = class MainPageModule {
};
MainPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _main_routing_module__WEBPACK_IMPORTED_MODULE_0__.MainPageRoutingModule
        ],
        declarations: [_main_page__WEBPACK_IMPORTED_MODULE_1__.MainPage]
    })
], MainPageModule);



/***/ }),

/***/ 3212:
/*!******************************************************!*\
  !*** ./src/app/authenticate/pages/main/main.page.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainPage": () => (/* binding */ MainPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _main_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main.page.html?ngResource */ 1318);
/* harmony import */ var _main_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./main.page.scss?ngResource */ 5594);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let MainPage = class MainPage {
    constructor() { }
    ngOnInit() {
    }
};
MainPage.ctorParameters = () => [];
MainPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-main',
        template: _main_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_main_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MainPage);



/***/ }),

/***/ 5594:
/*!*******************************************************************!*\
  !*** ./src/app/authenticate/pages/main/main.page.scss?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtYWluLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 1318:
/*!*******************************************************************!*\
  !*** ./src/app/authenticate/pages/main/main.page.html?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

module.exports = "  <ion-router-outlet></ion-router-outlet>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_main_main_module_ts.js.map