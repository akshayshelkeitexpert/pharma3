"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_offers_offers_module_ts"],{

/***/ 8430:
/*!********************************************************************!*\
  !*** ./src/app/authenticate/pages/offers/offers-routing.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OffersPageRoutingModule": () => (/* binding */ OffersPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _offers_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./offers.page */ 3950);




const routes = [
    {
        path: '',
        component: _offers_page__WEBPACK_IMPORTED_MODULE_0__.OffersPage
    }
];
let OffersPageRoutingModule = class OffersPageRoutingModule {
};
OffersPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], OffersPageRoutingModule);



/***/ }),

/***/ 5853:
/*!************************************************************!*\
  !*** ./src/app/authenticate/pages/offers/offers.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OffersPageModule": () => (/* binding */ OffersPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _offers_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./offers.page */ 3950);
/* harmony import */ var _offers_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./offers-routing.module */ 8430);







let OffersPageModule = class OffersPageModule {
};
OffersPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _offers_routing_module__WEBPACK_IMPORTED_MODULE_1__.OffersPageRoutingModule
        ],
        declarations: [_offers_page__WEBPACK_IMPORTED_MODULE_0__.OffersPage]
    })
], OffersPageModule);



/***/ }),

/***/ 3950:
/*!**********************************************************!*\
  !*** ./src/app/authenticate/pages/offers/offers.page.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OffersPage": () => (/* binding */ OffersPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _offers_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./offers.page.html?ngResource */ 7250);
/* harmony import */ var _offers_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./offers.page.scss?ngResource */ 4761);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let OffersPage = class OffersPage {
    constructor() { }
    ngOnInit() {
    }
};
OffersPage.ctorParameters = () => [];
OffersPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-offers',
        template: _offers_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_offers_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], OffersPage);



/***/ }),

/***/ 4761:
/*!***********************************************************************!*\
  !*** ./src/app/authenticate/pages/offers/offers.page.scss?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-offers ion-row.custome-box {\n  background: #FEBA7B;\n  border-radius: 14px;\n}\n::ng-deep app-offers .header {\n  top: 38px;\n  position: relative;\n  left: 12px;\n}\n::ng-deep app-offers .sales {\n  position: relative;\n  top: 8rem;\n}\n::ng-deep app-offers .logo {\n  width: 205px;\n}\n::ng-deep app-offers .recover {\n  bottom: 12px;\n  position: relative;\n}\n::ng-deep app-offers .recover .tag {\n  font-weight: 400;\n  font-size: 16px;\n}\n::ng-deep app-offers .recover .tag2 {\n  font-size: 12px;\n}\n::ng-deep app-offers ion-row .custom-textbox {\n  opacity: 0.5;\n  border: 1px solid #000000;\n  box-sizing: border-box;\n  border-radius: 60px;\n  color: #93949A;\n  padding: 7px 9px !important;\n  color: black;\n}\n::ng-deep app-offers ion-row.next-btn {\n  position: relative;\n  top: 21rem;\n}\n::ng-deep app-offers ion-row.forgot-btn {\n  position: relative;\n  top: 5rem;\n  text-decoration: none;\n  font-size: 20px;\n}\n::ng-deep app-offers .left-icon {\n  margin-left: 10px;\n  padding: 6px;\n}\n::ng-deep ion-footer {\n  position: fixed;\n  bottom: 0px;\n}\n::ng-deep ion-header {\n  position: static !important;\n}\n::ng-deep .offer-btn {\n  --background: #FFFFFF;\n  --box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.07);\n  --border-radius: 77px 60px 60px 0px;\n  height: 52px;\n  /* margin-left: 52px; */\n  width: 215px;\n}\n::ng-deep .custsegment {\n  background: #e9f0f7;\n  margin: 30px;\n  height: 41px;\n  border-radius: 50px;\n  background: linear-gradient(312.9deg, rgba(255, 255, 255, 0.3) 4.49%, rgba(233, 240, 247, 0.3) 95.45%), #ffffff;\n  box-shadow: -4px -4px 10px rgba(255, 255, 255, 0.9), 4px 4px 10px rgba(138, 155, 189, 0.4);\n  border-radius: 60px;\n}\n::ng-deep .custsegment ion-segment-button {\n  font-size: 12px;\n  --background-checked: linear-gradient(312.9deg, rgba(255, 255, 255, 0.3) 4.49%, rgba(233, 240, 247, 0.3) 95.45%),\n    #ffffff;\n  box-shadow: inset -4px -4px 10px rgba(255, 255, 255, 0.9), inset 4px 4px 10px rgba(138, 155, 189, 0.3);\n  border-radius: 60px;\n  --indicator-color: transparent !important;\n  color: #8f9bb2;\n}\n::ng-deep .custsegment ion-segment-button ion-label {\n  margin-top: 0px;\n  margin-bottom: 8px;\n}\n::ng-deep .custsegment .customrecentnote.selected {\n  box-shadow: none;\n}\n::ng-deep .custsegment .customrecentcall.selected {\n  box-shadow: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9mZmVycy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBSU07RUFDRSxtQkFBQTtFQUNBLG1CQUFBO0FBSFI7QUFRSTtFQUNFLFNBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUFOTjtBQVNJO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0FBUE47QUFVSTtFQUNFLFlBQUE7QUFSTjtBQVdJO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0FBVE47QUFXTTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtBQVRSO0FBWU07RUFDRSxlQUFBO0FBVlI7QUF1Qk07RUFDRSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0VBRUEsWUFBQTtBQXRCUjtBQXlCTTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtBQXZCUjtBQTBCTTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtBQXhCUjtBQThCSTtFQUNFLGlCQUFBO0VBQ0EsWUFBQTtBQTVCTjtBQWlDRTtFQUNFLGVBQUE7RUFDQSxXQUFBO0FBL0JKO0FBa0NFO0VBQ0UsMkJBQUE7QUFoQ0o7QUFtQ0U7RUFDRSxxQkFBQTtFQUNBLDhDQUFBO0VBQ0EsbUNBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0FBakNKO0FBc0NFO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsK0dBQUE7RUFDQSwwRkFBQTtFQUNBLG1CQUFBO0FBcENKO0FBdUNJO0VBQ0UsZUFBQTtFQUNBO1dBQUE7RUFFQSxzR0FBQTtFQUNBLG1CQUFBO0VBQ0EseUNBQUE7RUFDQSxjQUFBO0FBckNOO0FBd0NNO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FBdENSO0FBMENJO0VBQ0UsZ0JBQUE7QUF4Q047QUEyQ0k7RUFDRSxnQkFBQTtBQXpDTiIsImZpbGUiOiJvZmZlcnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIHtcclxuICBhcHAtb2ZmZXJzIHtcclxuXHJcbiAgICBpb24tcm93IHtcclxuICAgICAgJi5jdXN0b21lLWJveCB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI0ZFQkE3QjtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxNHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC5oZWFkZXIge1xyXG4gICAgICB0b3A6IDM4cHg7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgbGVmdDogMTJweDtcclxuICAgIH1cclxuXHJcbiAgICAuc2FsZXMge1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIHRvcDogOHJlbTtcclxuICAgIH1cclxuXHJcbiAgICAubG9nbyB7XHJcbiAgICAgIHdpZHRoOiAyMDVweDtcclxuICAgIH1cclxuXHJcbiAgICAucmVjb3ZlciB7XHJcbiAgICAgIGJvdHRvbTogMTJweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5cclxuICAgICAgLnRhZyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC50YWcyIHtcclxuICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG5cclxuICAgIC8vIC5pbnB1dCB7XHJcbiAgICAvLyAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIC8vICAgYm90dG9tOiAxNXB4O1xyXG4gICAgLy8gfVxyXG5cclxuXHJcbiAgICBpb24tcm93IHtcclxuICAgICAgLmN1c3RvbS10ZXh0Ym94IHtcclxuICAgICAgICBvcGFjaXR5OiAwLjU7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgIzAwMDAwMDtcclxuICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDYwcHg7XHJcbiAgICAgICAgY29sb3I6ICM5Mzk0OUE7XHJcbiAgICAgICAgcGFkZGluZzogN3B4IDlweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIC8vIG1hcmdpbi1sZWZ0OiAxMnB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgY29sb3I6IGJsYWNrO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAmLm5leHQtYnRuIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOiAyMXJlbTtcclxuICAgICAgfVxyXG5cclxuICAgICAgJi5mb3Jnb3QtYnRuIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOiA1cmVtO1xyXG4gICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAubWVudWwtdGV4dGJveCB7fVxyXG5cclxuICAgIC5sZWZ0LWljb24ge1xyXG4gICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgcGFkZGluZzogNnB4O1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG4gIGlvbi1mb290ZXIge1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgYm90dG9tOiAwcHg7XHJcbiAgfVxyXG5cclxuICBpb24taGVhZGVyIHtcclxuICAgIHBvc2l0aW9uOiBzdGF0aWMgIWltcG9ydGFudDtcclxuICB9XHJcblxyXG4gIC5vZmZlci1idG4ge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRkZGRkZGO1xyXG4gICAgLS1ib3gtc2hhZG93OiAwcHggNHB4IDE1cHggcmdiYSgwLCAwLCAwLCAwLjA3KTtcclxuICAgIC0tYm9yZGVyLXJhZGl1czogNzdweCA2MHB4IDYwcHggMHB4O1xyXG4gICAgaGVpZ2h0OiA1MnB4O1xyXG4gICAgLyogbWFyZ2luLWxlZnQ6IDUycHg7ICovXHJcbiAgICB3aWR0aDogMjE1cHg7XHJcblxyXG5cclxuICB9XHJcblxyXG4gIC5jdXN0c2VnbWVudCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZTlmMGY3O1xyXG4gICAgbWFyZ2luOiAzMHB4O1xyXG4gICAgaGVpZ2h0OiA0MXB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgzMTIuOWRlZywgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjMpIDQuNDklLCByZ2JhKDIzMywgMjQwLCAyNDcsIDAuMykgOTUuNDUlKSwgI2ZmZmZmZjtcclxuICAgIGJveC1zaGFkb3c6IC00cHggLTRweCAxMHB4IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC45KSwgNHB4IDRweCAxMHB4IHJnYmEoMTM4LCAxNTUsIDE4OSwgMC40KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDYwcHg7XHJcblxyXG4gICAgLy8gLS1pbmRpY2F0b3ItYm94LXNoYWRvdzogMXB4IDJweCAycHggI2NjYztcclxuICAgIGlvbi1zZWdtZW50LWJ1dHRvbiB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgLS1iYWNrZ3JvdW5kLWNoZWNrZWQ6IGxpbmVhci1ncmFkaWVudCgzMTIuOWRlZywgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjMpIDQuNDklLCByZ2JhKDIzMywgMjQwLCAyNDcsIDAuMykgOTUuNDUlKSxcclxuICAgICAgICAjZmZmZmZmO1xyXG4gICAgICBib3gtc2hhZG93OiBpbnNldCAtNHB4IC00cHggMTBweCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOSksIGluc2V0IDRweCA0cHggMTBweCByZ2JhKDEzOCwgMTU1LCAxODksIDAuMyk7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDYwcHg7XHJcbiAgICAgIC0taW5kaWNhdG9yLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gICAgICBjb2xvcjogIzhmOWJiMjtcclxuXHJcblxyXG4gICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDBweDtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiA4cHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuY3VzdG9tcmVjZW50bm90ZS5zZWxlY3RlZCB7XHJcbiAgICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICB9XHJcblxyXG4gICAgLmN1c3RvbXJlY2VudGNhbGwuc2VsZWN0ZWQge1xyXG4gICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcblxyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 7250:
/*!***********************************************************************!*\
  !*** ./src/app/authenticate/pages/offers/offers.page.html?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-padding-start ion-padding-top ion-padding-end\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n    </ion-buttons>\n    <ion-title>Offers</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <div>\n    <ion-row>\n      <ion-segment value=\"RecentNote\" class=\"custsegment\">\n        <ion-segment-button value=\"RecentNote\" class=\"customrecentnote\">\n          <ion-label>Recent Note</ion-label>\n        </ion-segment-button>\n        <ion-segment-button class=\"customrecentcall\">\n          <ion-label>Recent Call</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </ion-row>\n    <ion-row class=\"ion-margin custome-box\">\n      <ion-col size=\"12\" class=\"\">\n        <ion-text>\n          <p class=\"offer-heading\">Offer on<br><strong> Paracetamol</strong></p>\n          <p>of 5 Carton on purchase\n          </p>\n        </ion-text>\n      </ion-col>\n      <ion-col class=\"ion-no-margin\">\n        <p>End on : 5th May</p>\n        <p>Left:</p>\n      </ion-col>\n    </ion-row>\n  </div>\n  <ion-row class=\"text-center ion-margin\">\n    <ion-col size=\"12\">\n      <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/assosiates\" class=\"offer-btn\">View Offer\n      </ion-button>\n    </ion-col>\n  </ion-row>\n</ion-content>\n<!-- <ng-container>\n    <div>\n      <ion-row class=\"ion-margin sales\">\n        <ion-col size=\"12\" class=\"text-center\">\n          <img [src]=\"'assets/icon/mysales-ico.svg'\" class=\"logo\">\n        </ion-col>\n        <ion-col size=\"12\" class=\"text-center\">\n          <ion-text class=\"recover\">\n            <p class=\"tag\">There are no broadcuast sale offer of you<br> at this moment</p>\n            <p class=\"tag2\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.<br> Ullamcorper gravida et sit est\n            </p>\n          </ion-text>\n        </ion-col>\n      </ion-row>\n    </div>\n </ng-container> -->\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_offers_offers_module_ts.js.map