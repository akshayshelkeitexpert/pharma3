"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_reply-quotation_reply-quotation_module_ts"],{

/***/ 362:
/*!**************************************************************************************!*\
  !*** ./src/app/authenticate/pages/reply-quotation/reply-quotation-routing.module.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReplyQuotationPageRoutingModule": () => (/* binding */ ReplyQuotationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _reply_quotation_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reply-quotation.page */ 9664);




const routes = [
    {
        path: '',
        component: _reply_quotation_page__WEBPACK_IMPORTED_MODULE_0__.ReplyQuotationPage
    }
];
let ReplyQuotationPageRoutingModule = class ReplyQuotationPageRoutingModule {
};
ReplyQuotationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ReplyQuotationPageRoutingModule);



/***/ }),

/***/ 6152:
/*!******************************************************************************!*\
  !*** ./src/app/authenticate/pages/reply-quotation/reply-quotation.module.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReplyQuotationPageModule": () => (/* binding */ ReplyQuotationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _reply_quotation_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reply-quotation-routing.module */ 362);
/* harmony import */ var _reply_quotation_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reply-quotation.page */ 9664);







let ReplyQuotationPageModule = class ReplyQuotationPageModule {
};
ReplyQuotationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _reply_quotation_routing_module__WEBPACK_IMPORTED_MODULE_0__.ReplyQuotationPageRoutingModule
        ],
        declarations: [_reply_quotation_page__WEBPACK_IMPORTED_MODULE_1__.ReplyQuotationPage]
    })
], ReplyQuotationPageModule);



/***/ }),

/***/ 9664:
/*!****************************************************************************!*\
  !*** ./src/app/authenticate/pages/reply-quotation/reply-quotation.page.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReplyQuotationPage": () => (/* binding */ ReplyQuotationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _reply_quotation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reply-quotation.page.html?ngResource */ 5981);
/* harmony import */ var _reply_quotation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reply-quotation.page.scss?ngResource */ 155);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let ReplyQuotationPage = class ReplyQuotationPage {
    constructor() { }
    ngOnInit() {
    }
};
ReplyQuotationPage.ctorParameters = () => [];
ReplyQuotationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-reply-quotation',
        template: _reply_quotation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_reply_quotation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReplyQuotationPage);



/***/ }),

/***/ 155:
/*!*****************************************************************************************!*\
  !*** ./src/app/authenticate/pages/reply-quotation/reply-quotation.page.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZXBseS1xdW90YXRpb24ucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 5981:
/*!*****************************************************************************************!*\
  !*** ./src/app/authenticate/pages/reply-quotation/reply-quotation.page.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-padding-start ion-padding-top ion-padding-end\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n    </ion-buttons>\n    <ion-title>Reply Quotation</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-row class=\"ion-padding\">\n    <ion-col size=\"12\">\n      <ion-label class=\"offer-page\">Product Name</ion-label>\n      <br><br>\n      <ion-input type=\"text\" expand=\"block\" class=\"form-control custom-textbox\">\n      </ion-input>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-label class=\"offer-page\">Enter product name you want to offer on it</ion-label>\n      <br><br>\n      <ion-input type=\"text\" expand=\"block\" class=\"form-control custom-textbox\">\n      </ion-input>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-label class=\"offer-page\">Enter product name you want to offer on it</ion-label>\n      <br><br>\n      <ion-input type=\"text\" expand=\"block\" class=\"form-control custom-textbox\">\n      </ion-input>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-label class=\"offer-page\">Enter product name you want to offer on it</ion-label>\n      <br><br>\n      <ion-input type=\"text\" expand=\"block\" class=\"form-control custom-textbox\">\n      </ion-input>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-label class=\"offer-page\">Enter product name you want to offer on it</ion-label>\n      <br><br>\n      <ion-input type=\"text\" expand=\"block\" class=\"form-control custom-textbox\">\n      </ion-input>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-label class=\"offer-page\">Enter product name you want to offer on it</ion-label>\n      <br><br>\n      <ion-input type=\"text\" expand=\"block\" class=\"form-control custom-textbox\">\n      </ion-input>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-label class=\"offer-page\">Enter product name you want to offer on it</ion-label>\n      <br><br>\n      <ion-input type=\"text\" expand=\"block\" class=\"form-control custom-textbox\">\n      </ion-input>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-label class=\"offer-page\">Select date range</ion-label>\n      <br><br>\n      <ion-input type=\"text\" expand=\"block\" class=\"form-control custom-textbox\" placeholder=\"--select--\">\n      </ion-input>\n      <ion-icon class=\"right-icon\" [src]=\"'assets/icon/date-range-ico.svg'\"></ion-icon>\n    </ion-col>\n  </ion-row>\n\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_reply-quotation_reply-quotation_module_ts.js.map