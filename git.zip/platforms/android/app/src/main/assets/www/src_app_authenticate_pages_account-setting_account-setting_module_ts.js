"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_account-setting_account-setting_module_ts"],{

/***/ 3603:
/*!**************************************************************************************!*\
  !*** ./src/app/authenticate/pages/account-setting/account-setting-routing.module.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountSettingPageRoutingModule": () => (/* binding */ AccountSettingPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _account_setting_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./account-setting.page */ 4244);




const routes = [
    {
        path: '',
        component: _account_setting_page__WEBPACK_IMPORTED_MODULE_0__.AccountSettingPage
    },
    {
        path: 'account-updating-model',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_authenticate_pages_account-setting_account-updating-model_account-updating-model_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./account-updating-model/account-updating-model.module */ 6003)).then(m => m.AccountUpdatingModelPageModule)
    }
];
let AccountSettingPageRoutingModule = class AccountSettingPageRoutingModule {
};
AccountSettingPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AccountSettingPageRoutingModule);



/***/ }),

/***/ 4782:
/*!******************************************************************************!*\
  !*** ./src/app/authenticate/pages/account-setting/account-setting.module.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountSettingPageModule": () => (/* binding */ AccountSettingPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _account_setting_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./account-setting-routing.module */ 3603);
/* harmony import */ var _account_setting_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./account-setting.page */ 4244);







let AccountSettingPageModule = class AccountSettingPageModule {
};
AccountSettingPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _account_setting_routing_module__WEBPACK_IMPORTED_MODULE_0__.AccountSettingPageRoutingModule
        ],
        declarations: [_account_setting_page__WEBPACK_IMPORTED_MODULE_1__.AccountSettingPage]
    })
], AccountSettingPageModule);



/***/ }),

/***/ 4244:
/*!****************************************************************************!*\
  !*** ./src/app/authenticate/pages/account-setting/account-setting.page.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountSettingPage": () => (/* binding */ AccountSettingPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _account_setting_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./account-setting.page.html?ngResource */ 4941);
/* harmony import */ var _account_setting_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./account-setting.page.scss?ngResource */ 1013);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _account_updating_model_account_updating_model_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./account-updating-model/account-updating-model.page */ 4760);






let AccountSettingPage = class AccountSettingPage {
    constructor(modalCtrl) {
        this.modalCtrl = modalCtrl;
    }
    ngOnInit() {
    }
    plusbuttonmodel(reason, modalClass) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const presentModel = yield this.modalCtrl.create({
                component: _account_updating_model_account_updating_model_page__WEBPACK_IMPORTED_MODULE_2__.AccountUpdatingModelPage,
                componentProps: {
                    openedFor: reason
                },
                showBackdrop: true,
                mode: 'md',
                animated: true,
                cssClass: modalClass
            });
            yield presentModel.present();
        });
    }
};
AccountSettingPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController }
];
AccountSettingPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-account-setting',
        template: _account_setting_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_account_setting_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AccountSettingPage);



/***/ }),

/***/ 4760:
/*!**********************************************************************************************************!*\
  !*** ./src/app/authenticate/pages/account-setting/account-updating-model/account-updating-model.page.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountUpdatingModelPage": () => (/* binding */ AccountUpdatingModelPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _account_updating_model_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./account-updating-model.page.html?ngResource */ 5688);
/* harmony import */ var _account_updating_model_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./account-updating-model.page.scss?ngResource */ 4476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let AccountUpdatingModelPage = class AccountUpdatingModelPage {
    constructor() {
        this.openedFor = null;
    }
    ngOnInit() {
        console.log(this.openedFor);
    }
};
AccountUpdatingModelPage.ctorParameters = () => [];
AccountUpdatingModelPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-account-updating-model',
        template: _account_updating_model_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_account_updating_model_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AccountUpdatingModelPage);



/***/ }),

/***/ 1013:
/*!*****************************************************************************************!*\
  !*** ./src/app/authenticate/pages/account-setting/account-setting.page.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep .password-modal {\n  --height: 43%;\n  align-items: flex-end;\n}\n::ng-deep .name-modal,\n::ng-deep .phone-modal {\n  --height: 35%;\n  align-items: flex-end;\n}\n::ng-deep app-account-setting ion-content ion-list ion-item.main-card {\n  margin-bottom: -20px;\n  --background: #F6F8FA;\n  --border-radius: 31px 60px 60px 0px;\n}\n::ng-deep app-account-setting ion-content ion-list ion-item.main-card .details-ele {\n  position: relative;\n  left: 1pc;\n}\n::ng-deep app-account-setting ion-content ion-list ion-item.main-card .details-ele ion-label:nth-child(1) {\n  margin-bottom: 4px;\n}\n::ng-deep app-account-setting ion-content ion-list ion-label .label-desc {\n  font-size: 17px;\n  color: #31333D;\n  font-weight: 500;\n}\n::ng-deep app-account-setting ion-content ion-list ion-label .label-name {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 14px;\n  color: #31333D;\n}\n::ng-deep app-account-setting ion-content ion-list .forward-arrow {\n  position: relative;\n  right: -12px;\n  width: 18px;\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFjY291bnQtc2V0dGluZy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxhQUFBO0VBQ0EscUJBQUE7QUFBSjtBQUdFOztFQUVFLGFBQUE7RUFDQSxxQkFBQTtBQURKO0FBUVE7RUFDRSxvQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUNBQUE7QUFOVjtBQVNVO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0FBUFo7QUFTWTtFQUNFLGtCQUFBO0FBUGQ7QUFhVTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFYWjtBQWNVO0VBQ0UscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFaWjtBQWdCUTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBZFYiLCJmaWxlIjoiYWNjb3VudC1zZXR0aW5nLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjo6bmctZGVlcCB7XHJcbiAgLnBhc3N3b3JkLW1vZGFsIHtcclxuICAgIC0taGVpZ2h0OiA0MyU7XHJcbiAgICBhbGlnbi1pdGVtczogZmxleC1lbmQ7XHJcbiAgfVxyXG5cclxuICAubmFtZS1tb2RhbCxcclxuICAucGhvbmUtbW9kYWwge1xyXG4gICAgLS1oZWlnaHQ6IDM1JTtcclxuICAgIGFsaWduLWl0ZW1zOiBmbGV4LWVuZDtcclxuXHJcbiAgfVxyXG5cclxuICBhcHAtYWNjb3VudC1zZXR0aW5nIHtcclxuICAgIGlvbi1jb250ZW50IHtcclxuICAgICAgaW9uLWxpc3Qge1xyXG4gICAgICAgIGlvbi1pdGVtLm1haW4tY2FyZCB7XHJcbiAgICAgICAgICBtYXJnaW4tYm90dG9tOiAtMjBweDtcclxuICAgICAgICAgIC0tYmFja2dyb3VuZDogI0Y2RjhGQTtcclxuICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogMzFweCA2MHB4IDYwcHggMHB4O1xyXG5cclxuICAgICAgICAgIC8vICAgaGVpZ2h0OiA3NXB4O1xyXG4gICAgICAgICAgLmRldGFpbHMtZWxlIHtcclxuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgICBsZWZ0OiAxcGM7XHJcblxyXG4gICAgICAgICAgICBpb24tbGFiZWw6bnRoLWNoaWxkKDEpIHtcclxuICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICAubGFiZWwtZGVzYyB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTdweDtcclxuICAgICAgICAgICAgY29sb3I6ICMzMTMzM0Q7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgLmxhYmVsLW5hbWUge1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1JvYm90byc7XHJcbiAgICAgICAgICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgICAgICBjb2xvcjogIzMxMzMzRDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5mb3J3YXJkLWFycm93IHtcclxuICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICAgIHJpZ2h0OiAtMTJweDtcclxuICAgICAgICAgIHdpZHRoOiAxOHB4O1xyXG4gICAgICAgICAgY29sb3I6IGJsYWNrO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0= */";

/***/ }),

/***/ 4476:
/*!***********************************************************************************************************************!*\
  !*** ./src/app/authenticate/pages/account-setting/account-updating-model/account-updating-model.page.scss?ngResource ***!
  \***********************************************************************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-account-updating-model ion-content ion-row.model {\n  position: relative;\n  top: 49px;\n}\n::ng-deep app-account-updating-model ion-content ion-row.model-password {\n  position: relative;\n  top: 23px;\n}\n::ng-deep app-account-updating-model ion-content ion-row.next-btn {\n  position: relative;\n  top: 22px;\n  box-sizing: border-box;\n  border-radius: 60px;\n}\n::ng-deep app-account-updating-model ion-content .model-newpassword {\n  top: 29px;\n}\n::ng-deep app-account-updating-model ion-content .custom-textbox {\n  box-sizing: border-box;\n  border-radius: 60px;\n}\n::ng-deep app-account-updating-model ion-content .username {\n  position: relative;\n  /* top: -1rem; */\n  bottom: 10px;\n  font-family: \"Roboto\";\n  /* font-style: normal; */\n  /* font-weight: 400; */\n  font-size: 14px;\n  line-height: 16px;\n  color: #31333D;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFjY291bnQtdXBkYXRpbmctbW9kZWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUlRO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0FBSFY7QUFNUTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtBQUpWO0FBUVE7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0FBTlY7QUFXTTtFQUNFLFNBQUE7QUFUUjtBQVlNO0VBQ0Usc0JBQUE7RUFDQSxtQkFBQTtBQVZSO0FBYU07RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0Esd0JBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFYUiIsImZpbGUiOiJhY2NvdW50LXVwZGF0aW5nLW1vZGVsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjo6bmctZGVlcCB7XHJcbiAgYXBwLWFjY291bnQtdXBkYXRpbmctbW9kZWwge1xyXG4gICAgaW9uLWNvbnRlbnQge1xyXG4gICAgICBpb24tcm93IHtcclxuICAgICAgICAmLm1vZGVsIHtcclxuICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICAgIHRvcDogNDlweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICYubW9kZWwtcGFzc3dvcmQge1xyXG4gICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgdG9wOiAyM3B4O1xyXG5cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICYubmV4dC1idG4ge1xyXG4gICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgdG9wOiAyMnB4O1xyXG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDYwcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgfVxyXG5cclxuICAgICAgLm1vZGVsLW5ld3Bhc3N3b3JkIHtcclxuICAgICAgICB0b3A6IDI5cHhcclxuICAgICAgfVxyXG5cclxuICAgICAgLmN1c3RvbS10ZXh0Ym94IHtcclxuICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDYwcHg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC51c2VybmFtZSB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIC8qIHRvcDogLTFyZW07ICovXHJcbiAgICAgICAgYm90dG9tOiAxMHB4O1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcclxuICAgICAgICAvKiBmb250LXN0eWxlOiBub3JtYWw7ICovXHJcbiAgICAgICAgLyogZm9udC13ZWlnaHQ6IDQwMDsgKi9cclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDE2cHg7XHJcbiAgICAgICAgY29sb3I6ICMzMTMzM0Q7XHJcblxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 4941:
/*!*****************************************************************************************!*\
  !*** ./src/app/authenticate/pages/account-setting/account-setting.page.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-padding-start ion-padding-top ion-padding-end\">\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n    </ion-buttons> -->\n    <ion-title>Account Seetings</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-list lines=\"none\">\n    <ion-item class=\"main-card ion-padding\">\n      <div class=\"details-ele\">\n        <ion-label><span class=\"label-name\"> User name</span></ion-label>\n        <ion-label><span class=\"label-desc\">Akshay</span></ion-label>\n      </div>\n      <ion-icon slot=\"end\" class=\"forward-arrow\" name=\"chevron-forward\" (click)=\"plusbuttonmodel('name','name-modal')\">\n      </ion-icon>\n    </ion-item>\n\n    <ion-item class=\"main-card ion-padding\">\n      <div class=\"details-ele\">\n        <ion-label><span class=\"label-name\"> Phone Number</span></ion-label>\n        <ion-label><span class=\"label-desc\">+91 9012 345678</span></ion-label>\n      </div>\n      <ion-icon slot=\"end\" class=\"forward-arrow\" name=\"chevron-forward\"\n        (click)=\"plusbuttonmodel('phone','phone-modal')\"></ion-icon>\n    </ion-item>\n\n    <ion-item class=\"main-card ion-padding\">\n      <div class=\"details-ele\">\n        <ion-label><span class=\"label-name\">Location</span></ion-label>\n        <ion-label><span class=\"label-desc\">235/a Lorem ipsum dummy addresss</span></ion-label>\n      </div>\n      <!-- <ion-icon slot=\"end\" class=\"forward-arrow\" name=\"chevron-forward\"></ion-icon> -->\n    </ion-item>\n\n    <ion-item class=\"main-card ion-padding\">\n      <div class=\"details-ele\">\n        <ion-label><span class=\"label-name\">State</span></ion-label>\n        <ion-label><span class=\"label-desc\">West Bengal</span></ion-label>\n      </div>\n      <!-- <ion-icon slot=\"end\" class=\"forward-arrow\" name=\"chevron-forward\"></ion-icon> -->\n    </ion-item>\n    <ion-item class=\"main-card ion-padding\">\n      <div class=\"details-ele\">\n        <ion-label><span class=\"label-name\">Station</span></ion-label>\n        <ion-label><span class=\"label-desc\">Howrah</span></ion-label>\n      </div>\n      <ion-icon slot=\"end\" class=\"forward-arrow\" name=\"chevron-forward\"></ion-icon>\n    </ion-item>\n    <ion-item class=\"main-card ion-padding\">\n      <div class=\"details-ele\">\n        <!-- <ion-label><span class=\"label-name\">Change Password </span></ion-label> -->\n        <ion-label><span class=\"label-desc\">Change Password</span></ion-label>\n      </div>\n      <ion-icon slot=\"end\" class=\"forward-arrow\" (click)=\"plusbuttonmodel('password','password-modal')\"\n        name=\"chevron-forward\">\n      </ion-icon>\n    </ion-item>\n    <ion-item class=\"main-card ion-padding\">\n      <div class=\"details-ele\">\n        <!-- <ion-label><span class=\"label-name\"> Comments</span></ion-label> -->\n        <ion-label><span class=\"label-desc\">Comments</span></ion-label>\n      </div>\n      <ion-icon slot=\"end\" class=\"forward-arrow\" name=\"chevron-forward\"></ion-icon>\n    </ion-item>\n  </ion-list>\n\n</ion-content>\n";

/***/ }),

/***/ 5688:
/*!***********************************************************************************************************************!*\
  !*** ./src/app/authenticate/pages/account-setting/account-updating-model/account-updating-model.page.html?ngResource ***!
  \***********************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <form>\n    <ng-container *ngIf=\"openedFor =='name'\">\n      <div class=\"login-screen ion-padding\">\n        <ion-row class=\"ion-margin ion-padding-top model\">\n          <ion-col size=\"12\">\n            <ion-label class=\"username\">User Name</ion-label>\n            <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\">\n            </ion-input>\n          </ion-col>\n        </ion-row>\n        <br>\n        <ion-row class=\"next-btn ion-padding-top ion-margin \">\n          <ion-col size=\"12\">\n            <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/assosiates\" class=\"custom-btn\">Next\n            </ion-button>\n          </ion-col>\n        </ion-row>\n        <br>\n      </div>\n    </ng-container>\n\n\n    <ng-container *ngIf=\"openedFor =='phone'\">\n      <div class=\"login-screen ion-padding\">\n        <ion-row class=\"ion-margin ion-padding-top model\">\n          <ion-col size=\"12\">\n            <ion-label class=\"username\">Phone Number</ion-label>\n            <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\">\n\n            </ion-input>\n          </ion-col>\n        </ion-row>\n        <br>\n        <ion-row class=\"next-btn ion-padding-top ion-margin \">\n          <ion-col size=\"12\">\n            <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/assosiates\" class=\"custom-btn\">SAVE\n            </ion-button>\n          </ion-col>\n        </ion-row>\n        <br>\n      </div>\n    </ng-container>\n\n\n    <ng-container *ngIf=\"openedFor =='password'\">\n      <div class=\"login-screen ion-padding\">\n        <ion-row class=\"ion-margin ion-padding-top model-password\">\n          <ion-col size=\"12\">\n            <ion-label class=\"username\">Old Password</ion-label>\n            <ion-input autocomplete=\"off\" [type]=\"showPsw ? 'text' : 'password'\" expand=\"block\"\n              class=\"form-control custom-textbox right-icon-available\" placeholder=\"Password\">\n\n              <ion-icon *ngIf=\"showPsw==true\" (click)=\"changePassword()\" class=\"right-icon\"\n                [src]=\"'assets/icon/pass-eye-close-ico.svg'\" color=\"warning\"></ion-icon>\n              <ion-icon [src]=\"'assets/icon/pass-eye-close-ico.svg'\" (click)=\"changePassword()\" class=\"right-icon\"\n                *ngIf=\"showPsw==false\" color=\"warning\">\n              </ion-icon>\n            </ion-input>\n          </ion-col>\n          <ion-col size=\"12\" class=\"model-newpassword\">\n            <ion-label class=\"username\">New Password</ion-label>\n            <ion-input autocomplete=\"off\" [type]=\"showPsw ? 'text' : 'password'\" expand=\"block\"\n              class=\"form-control custom-textbox right-icon-available\" placeholder=\"Password\">\n\n\n              <ion-icon *ngIf=\"showPsw==true\" (click)=\"changePassword()\" class=\"right-icon\"\n                [src]=\"'assets/icon/pass-eye-close-ico.svg'\" color=\"warning\"></ion-icon>\n              <ion-icon [src]=\"'assets/icon/pass-eye-close-ico.svg'\" (click)=\"changePassword()\" class=\"right-icon\"\n                *ngIf=\"showPsw==false\" color=\"warning\">\n              </ion-icon>\n            </ion-input>\n          </ion-col>\n        </ion-row>\n        <br>\n        <ion-row class=\"next-btn ion-padding-top ion-margin \">\n          <ion-col size=\"12\">\n            <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/assosiates\" class=\"custom-btn\">SAVE\n            </ion-button>\n          </ion-col>\n        </ion-row>\n        <br>\n      </div>\n    </ng-container>\n\n  </form>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_account-setting_account-setting_module_ts.js.map