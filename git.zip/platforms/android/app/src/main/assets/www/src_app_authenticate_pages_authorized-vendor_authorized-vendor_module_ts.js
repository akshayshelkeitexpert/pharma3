"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_authorized-vendor_authorized-vendor_module_ts"],{

/***/ 6179:
/*!******************************************************************************************!*\
  !*** ./src/app/authenticate/pages/authorized-vendor/authorized-vendor-routing.module.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthorizedVendorPageRoutingModule": () => (/* binding */ AuthorizedVendorPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _authorized_vendor_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./authorized-vendor.page */ 7023);




const routes = [
    {
        path: '',
        component: _authorized_vendor_page__WEBPACK_IMPORTED_MODULE_0__.AuthorizedVendorPage
    }
];
let AuthorizedVendorPageRoutingModule = class AuthorizedVendorPageRoutingModule {
};
AuthorizedVendorPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AuthorizedVendorPageRoutingModule);



/***/ }),

/***/ 3060:
/*!**********************************************************************************!*\
  !*** ./src/app/authenticate/pages/authorized-vendor/authorized-vendor.module.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthorizedVendorPageModule": () => (/* binding */ AuthorizedVendorPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _authorized_vendor_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./authorized-vendor-routing.module */ 6179);
/* harmony import */ var _authorized_vendor_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./authorized-vendor.page */ 7023);







let AuthorizedVendorPageModule = class AuthorizedVendorPageModule {
};
AuthorizedVendorPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _authorized_vendor_routing_module__WEBPACK_IMPORTED_MODULE_0__.AuthorizedVendorPageRoutingModule
        ],
        declarations: [_authorized_vendor_page__WEBPACK_IMPORTED_MODULE_1__.AuthorizedVendorPage]
    })
], AuthorizedVendorPageModule);



/***/ }),

/***/ 7023:
/*!********************************************************************************!*\
  !*** ./src/app/authenticate/pages/authorized-vendor/authorized-vendor.page.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthorizedVendorPage": () => (/* binding */ AuthorizedVendorPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _authorized_vendor_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./authorized-vendor.page.html?ngResource */ 8740);
/* harmony import */ var _authorized_vendor_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./authorized-vendor.page.scss?ngResource */ 8908);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let AuthorizedVendorPage = class AuthorizedVendorPage {
    constructor() { }
    ngOnInit() {
    }
};
AuthorizedVendorPage.ctorParameters = () => [];
AuthorizedVendorPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-authorized-vendor',
        template: _authorized_vendor_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_authorized_vendor_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AuthorizedVendorPage);



/***/ }),

/***/ 8908:
/*!*********************************************************************************************!*\
  !*** ./src/app/authenticate/pages/authorized-vendor/authorized-vendor.page.scss?ngResource ***!
  \*********************************************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-authorized-vendor ion-content ion-list ion-item.main-card {\n  margin-bottom: -20px;\n  --background: #F6F8FA;\n  --border-radius: 31px 60px 60px 0px;\n}\n::ng-deep app-authorized-vendor ion-content ion-list ion-item.main-card .details-ele {\n  position: relative;\n  left: 1pc;\n}\n::ng-deep app-authorized-vendor ion-content ion-list ion-item.main-card .details-ele ion-label:nth-child(1) {\n  margin-bottom: 4px;\n}\n::ng-deep app-authorized-vendor ion-content ion-list ion-label .label-desc {\n  font-size: 17px;\n  color: #31333D;\n  font-weight: 500;\n}\n::ng-deep app-authorized-vendor ion-content ion-list ion-label .label-name {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 14px;\n  color: #31333D;\n}\n::ng-deep app-authorized-vendor ion-content ion-list .forward-arrow {\n  position: relative;\n  right: -12px;\n  width: 18px;\n  color: black;\n}\n::ng-deep app-authorized-vendor ion-content .next-btn {\n  position: relative;\n  top: 25rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dGhvcml6ZWQtdmVuZG9yLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJUTtFQUNFLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSxtQ0FBQTtBQUhWO0FBTVU7RUFDRSxrQkFBQTtFQUNBLFNBQUE7QUFKWjtBQU1ZO0VBQ0Usa0JBQUE7QUFKZDtBQVVVO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQVJaO0FBV1U7RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQVRaO0FBYVE7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQVhWO0FBZU07RUFDRSxrQkFBQTtFQUNBLFVBQUE7QUFiUiIsImZpbGUiOiJhdXRob3JpemVkLXZlbmRvci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6Om5nLWRlZXAge1xyXG4gIGFwcC1hdXRob3JpemVkLXZlbmRvciB7XHJcbiAgICBpb24tY29udGVudCB7XHJcbiAgICAgIGlvbi1saXN0IHtcclxuICAgICAgICBpb24taXRlbS5tYWluLWNhcmQge1xyXG4gICAgICAgICAgbWFyZ2luLWJvdHRvbTogLTIwcHg7XHJcbiAgICAgICAgICAtLWJhY2tncm91bmQ6ICNGNkY4RkE7XHJcbiAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDMxcHggNjBweCA2MHB4IDBweDtcclxuXHJcbiAgICAgICAgICAvLyAgIGhlaWdodDogNzVweDtcclxuICAgICAgICAgIC5kZXRhaWxzLWVsZSB7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICAgICAgbGVmdDogMXBjO1xyXG5cclxuICAgICAgICAgICAgaW9uLWxhYmVsOm50aC1jaGlsZCgxKSB7XHJcbiAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgICAgLmxhYmVsLWRlc2Mge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMzEzMzNEO1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIC5sYWJlbC1uYW1lIHtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xyXG4gICAgICAgICAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgY29sb3I6ICMzMTMzM0Q7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuZm9yd2FyZC1hcnJvdyB7XHJcbiAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICByaWdodDogLTEycHg7XHJcbiAgICAgICAgICB3aWR0aDogMThweDtcclxuICAgICAgICAgIGNvbG9yOiBibGFjaztcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5uZXh0LWJ0biB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHRvcDogMjVyZW07XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 8740:
/*!*********************************************************************************************!*\
  !*** ./src/app/authenticate/pages/authorized-vendor/authorized-vendor.page.html?ngResource ***!
  \*********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-padding-start ion-padding-top ion-padding-end\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n    </ion-buttons>\n    <ion-title>Authorized Vendor</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-list lines=\"none\">\n    <ion-item class=\"main-card ion-padding\">\n      <div class=\"details-ele\">\n        <ion-label><span class=\"label-desc\">Company Name:</span></ion-label>\n        <ion-label><span class=\"label-name\">ABCD Company Private Limited</span></ion-label>\n\n      </div>\n      <ion-icon slot=\"end\" class=\"forward-arrow\" name=\"chevron-forward\" (click)=\"plusbuttonmodel()\"></ion-icon>\n    </ion-item>\n    <ion-item class=\"main-card ion-padding\">\n      <div class=\"details-ele\">\n        <ion-label><span class=\"label-desc\">Company Name:</span></ion-label>\n        <ion-label><span class=\"label-name\">ABCD Company Private Limited</span></ion-label>\n\n      </div>\n      <ion-icon slot=\"end\" class=\"forward-arrow\" name=\"chevron-forward\" (click)=\"plusbuttonmodel()\"></ion-icon>\n    </ion-item>\n    <ion-item class=\"main-card ion-padding\">\n      <div class=\"details-ele\">\n        <ion-label><span class=\"label-desc\">Company Name:</span></ion-label>\n        <ion-label><span class=\"label-name\">ABCD Company Private Limited</span></ion-label>\n\n      </div>\n      <ion-icon slot=\"end\" class=\"forward-arrow\" name=\"chevron-forward\" (click)=\"plusbuttonmodel()\"></ion-icon>\n    </ion-item>\n  </ion-list>\n  <ion-row class=\"next-btn ion-padding-top ion-margin \">\n    <ion-col size=\"12\">\n      <ion-button expand=\"block\" type=\"submit\" class=\"custom-btn\">Add Authorized vendor\n      </ion-button>\n    </ion-col>\n  </ion-row>\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_authorized-vendor_authorized-vendor_module_ts.js.map