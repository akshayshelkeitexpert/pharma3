"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_notification_notification_module_ts"],{

/***/ 8205:
/*!********************************************************************************!*\
  !*** ./src/app/authenticate/pages/notification/notification-routing.module.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationPageRoutingModule": () => (/* binding */ NotificationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _notification_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification.page */ 7643);




const routes = [
    {
        path: '',
        component: _notification_page__WEBPACK_IMPORTED_MODULE_0__.NotificationPage
    }
];
let NotificationPageRoutingModule = class NotificationPageRoutingModule {
};
NotificationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NotificationPageRoutingModule);



/***/ }),

/***/ 1496:
/*!************************************************************************!*\
  !*** ./src/app/authenticate/pages/notification/notification.module.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationPageModule": () => (/* binding */ NotificationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _notification_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification-routing.module */ 8205);
/* harmony import */ var _notification_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification.page */ 7643);







let NotificationPageModule = class NotificationPageModule {
};
NotificationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _notification_routing_module__WEBPACK_IMPORTED_MODULE_0__.NotificationPageRoutingModule
        ],
        declarations: [_notification_page__WEBPACK_IMPORTED_MODULE_1__.NotificationPage]
    })
], NotificationPageModule);



/***/ }),

/***/ 7643:
/*!**********************************************************************!*\
  !*** ./src/app/authenticate/pages/notification/notification.page.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationPage": () => (/* binding */ NotificationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _notification_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification.page.html?ngResource */ 9380);
/* harmony import */ var _notification_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification.page.scss?ngResource */ 6803);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let NotificationPage = class NotificationPage {
    constructor() {
        this.notifications = [
            {
                title: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Porttitor leo ornare cras varius eget sit lacus. Condimentum eros, sit aenean nunc vestibulum in adipiscing viverra porta.Aliquet quam molestie vehicula sed.", date: "22nd Feb, 01:26 PM", isGreen: true
            },
            {
                title: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Porttitor leo ornare cras varius eget sit lacus. Condimentum eros, sit aenean nunc vestibulum in adipiscing viverra porta.Aliquet quam molestie vehicula sed.", date: "22nd Feb, 01:26 PM", isGreen: false
            },
            {
                title: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Porttitor leo ornare cras varius eget sit lacus. Condimentum eros, sit aenean nunc vestibulum in adipiscing viverra porta.Aliquet quam molestie vehicula sed.", date: "22nd Feb, 01:26 PM", isGreen: true
            },
            {
                title: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Porttitor leo ornare cras varius eget sit lacus. Condimentum eros, sit aenean nunc vestibulum in adipiscing viverra porta.Aliquet quam molestie vehicula sed.", date: "22nd Feb, 01:26 PM", isGreen: true
            },
            {
                title: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Porttitor leo ornare cras varius eget sit lacus. Condimentum eros, sit aenean nunc vestibulum in adipiscing viverra porta.Aliquet quam molestie vehicula sed.", date: "22nd Feb, 01:26 PM", isGreen: false
            },
            {
                title: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Porttitor leo ornare cras varius eget sit lacus. Condimentum eros, sit aenean nunc vestibulum in adipiscing viverra porta.Aliquet quam molestie vehicula sed.", date: "22nd Feb, 01:26 PM", isGreen: true
            },
            {
                title: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Porttitor leo ornare cras varius eget sit lacus. Condimentum eros, sit aenean nunc vestibulum in adipiscing viverra porta.Aliquet quam molestie vehicula sed.", date: "22nd Feb, 01:26 PM", isGreen: false
            }
        ];
    }
    ngOnInit() {
    }
};
NotificationPage.ctorParameters = () => [];
NotificationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-notification',
        template: _notification_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_notification_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NotificationPage);



/***/ }),

/***/ 6803:
/*!***********************************************************************************!*\
  !*** ./src/app/authenticate/pages/notification/notification.page.scss?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-notification ion-content ion-row .col .main-card {\n  border-radius: 18px 18px 18px 0px;\n  padding: 1px 10px 1px 15px;\n}\n::ng-deep app-notification ion-content ion-row .col .main-card.white-shade {\n  background: #F6F8FA !important;\n}\n::ng-deep app-notification ion-content ion-row .col .main-card.white-shade .card-heading {\n  color: #10A8A0;\n}\n::ng-deep app-notification ion-content ion-row .col .main-card.white-shade .card-description {\n  color: #93949A;\n}\n::ng-deep app-notification ion-content ion-row .col .main-card.white-shade .card-date {\n  color: #9A9BA1;\n}\n::ng-deep app-notification ion-content ion-row .col .main-card.green-shade {\n  background: #CAEBE9 !important;\n}\n::ng-deep app-notification ion-content ion-row .col .main-card.green-shade .card-heading {\n  color: #3E3D3D;\n}\n::ng-deep app-notification ion-content ion-row .col .main-card.green-shade .card-description {\n  color: #93949A;\n}\n::ng-deep app-notification ion-content ion-row .col .main-card.green-shade .card-date {\n  color: #9A9BA1;\n}\n::ng-deep app-notification ion-content ion-row .col .main-card .card-heading {\n  font-size: 16px;\n}\n::ng-deep app-notification ion-content ion-row .col .main-card .card-description {\n  font-size: 11px;\n}\n::ng-deep app-notification ion-content ion-row .col .main-card .card-date {\n  font-size: 10px;\n  font-style: italic;\n  text-align: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vdGlmaWNhdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBT1U7RUFrQ0UsaUNBQUE7RUFDQSwwQkFBQTtBQXZDWjtBQU1ZO0VBQ0UsOEJBQUE7QUFKZDtBQU1jO0VBQ0UsY0FBQTtBQUpoQjtBQU9jO0VBQ0UsY0FBQTtBQUxoQjtBQVFjO0VBQ0UsY0FBQTtBQU5oQjtBQVVZO0VBQ0UsOEJBQUE7QUFSZDtBQVVjO0VBQ0UsY0FBQTtBQVJoQjtBQVdjO0VBQ0UsY0FBQTtBQVRoQjtBQVljO0VBQ0UsY0FBQTtBQVZoQjtBQWlCWTtFQUNFLGVBQUE7QUFmZDtBQWtCWTtFQUNFLGVBQUE7QUFoQmQ7QUFtQlk7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQWpCZCIsImZpbGUiOiJub3RpZmljYXRpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIHtcclxuICBhcHAtbm90aWZpY2F0aW9uIHtcclxuICAgIGlvbi1jb250ZW50IHtcclxuICAgICAgaW9uLXJvdyB7XHJcbiAgICAgICAgLmNvbCB7XHJcbiAgICAgICAgICAvLyAgIG1hcmdpbi10b3A6IDIwcHg7XHJcblxyXG4gICAgICAgICAgLm1haW4tY2FyZCB7XHJcblxyXG4gICAgICAgICAgICAmLndoaXRlLXNoYWRlIHtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjRjZGOEZBICFpbXBvcnRhbnQ7XHJcblxyXG4gICAgICAgICAgICAgIC5jYXJkLWhlYWRpbmcge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICMxMEE4QTA7XHJcbiAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAuY2FyZC1kZXNjcmlwdGlvbiB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogIzkzOTQ5QTtcclxuICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgIC5jYXJkLWRhdGUge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICM5QTlCQTE7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAmLmdyZWVuLXNoYWRlIHtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjQ0FFQkU5ICFpbXBvcnRhbnQ7XHJcblxyXG4gICAgICAgICAgICAgIC5jYXJkLWhlYWRpbmcge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICMzRTNEM0Q7XHJcbiAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAuY2FyZC1kZXNjcmlwdGlvbiB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogIzkzOTQ5QTtcclxuICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgIC5jYXJkLWRhdGUge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICM5QTlCQTE7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxOHB4IDE4cHggMThweCAwcHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDFweCAxMHB4IDFweCAxNXB4O1xyXG5cclxuICAgICAgICAgICAgLmNhcmQtaGVhZGluZyB7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuY2FyZC1kZXNjcmlwdGlvbiB7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuY2FyZC1kYXRlIHtcclxuICAgICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICAgICAgICAgICAgZm9udC1zdHlsZTogaXRhbGljO1xyXG4gICAgICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICB9XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 9380:
/*!***********************************************************************************!*\
  !*** ./src/app/authenticate/pages/notification/notification.page.html?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-padding-start ion-padding-top ion-padding-end\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n    </ion-buttons>\n    <ion-title>Notification</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-row class=\"ion-padding-start ion-padding-end\">\n    <ion-col size=\"12\" class=\"col\" *ngFor=\"let item of notifications\">\n      <div class=\"main-card\" [ngClass]=\"item.isGreen ? 'green-shade' : 'white-shade'\">\n        <p class=\"card-heading\"><strong>{{item.title}}</strong></p>\n        <p class=\"card-description\">{{item.description}}</p>\n        <p class=\"card-date\">{{item.date}}</p>\n      </div>\n    </ion-col>\n  </ion-row>\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_notification_notification_module_ts.js.map