"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_authenticate_pages_associates-details_associates-details_module_ts"],{

/***/ 4488:
/*!********************************************************************************************!*\
  !*** ./src/app/authenticate/pages/associates-details/associates-details-routing.module.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AssociatesDetailsPageRoutingModule": () => (/* binding */ AssociatesDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _associates_details_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./associates-details.page */ 3086);




const routes = [
    {
        path: '',
        component: _associates_details_page__WEBPACK_IMPORTED_MODULE_0__.AssociatesDetailsPage
    }
];
let AssociatesDetailsPageRoutingModule = class AssociatesDetailsPageRoutingModule {
};
AssociatesDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AssociatesDetailsPageRoutingModule);



/***/ }),

/***/ 4535:
/*!************************************************************************************!*\
  !*** ./src/app/authenticate/pages/associates-details/associates-details.module.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AssociatesDetailsPageModule": () => (/* binding */ AssociatesDetailsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _associates_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./associates-details-routing.module */ 4488);
/* harmony import */ var _associates_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./associates-details.page */ 3086);







let AssociatesDetailsPageModule = class AssociatesDetailsPageModule {
};
AssociatesDetailsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _associates_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.AssociatesDetailsPageRoutingModule
        ],
        declarations: [_associates_details_page__WEBPACK_IMPORTED_MODULE_1__.AssociatesDetailsPage]
    })
], AssociatesDetailsPageModule);



/***/ }),

/***/ 3086:
/*!**********************************************************************************!*\
  !*** ./src/app/authenticate/pages/associates-details/associates-details.page.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AssociatesDetailsPage": () => (/* binding */ AssociatesDetailsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _associates_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./associates-details.page.html?ngResource */ 1895);
/* harmony import */ var _associates_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./associates-details.page.scss?ngResource */ 3607);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let AssociatesDetailsPage = class AssociatesDetailsPage {
    constructor() { }
    ngOnInit() {
    }
};
AssociatesDetailsPage.ctorParameters = () => [];
AssociatesDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-associates-details',
        template: _associates_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_associates_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AssociatesDetailsPage);



/***/ }),

/***/ 3607:
/*!***********************************************************************************************!*\
  !*** ./src/app/authenticate/pages/associates-details/associates-details.page.scss?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-associates-details ion-row.list {\n  background: #F6F8FA;\n  border-radius: 31px 31px 31px 0px;\n}\n::ng-deep app-associates-details ion-row.list p.line {\n  border: 1px solid black;\n  width: 100%;\n  margin: 38px 17px -9px 17px;\n  opacity: 0.3;\n}\n::ng-deep app-associates-details ion-row .profile-details {\n  position: relative;\n  top: 43px;\n}\n::ng-deep app-associates-details .tag1 {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 16px;\n  /* identical to box height, or 89% */\n  color: #31333D;\n}\n::ng-deep app-associates-details .tag2 {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 16px;\n  color: #31333D;\n}\n::ng-deep app-associates-details .tag3 {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 16px;\n  /* identical to box height, or 100% */\n  color: #31333D;\n}\n::ng-deep app-associates-details .list-heading {\n  margin-top: -38px;\n}\n::ng-deep app-associates-details h1,\n::ng-deep app-associates-details h2,\n::ng-deep app-associates-details h3,\n::ng-deep app-associates-details h4,\n::ng-deep app-associates-details h5,\n::ng-deep app-associates-details h6 {\n  margin-top: -1px;\n  margin-bottom: 10px;\n  font-weight: 500;\n  line-height: 1.2;\n}\n::ng-deep app-associates-details .profile {\n  max-width: 100%;\n  border: 0;\n  height: 109px;\n  position: relative;\n  top: 81px;\n}\n::ng-deep app-associates-details ion-row.next-btn {\n  position: relative;\n  top: 13rem;\n}\n::ng-deep app-associates-details .custom-text {\n  --background: #FF4E4E;\n  --border-radius: 83px 60px 60px 0px !important;\n  height: 54px;\n  --box-shadow: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc29jaWF0ZXMtZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR007RUFDRSxtQkFBQTtFQUNBLGlDQUFBO0FBRlI7QUFNUTtFQUNFLHVCQUFBO0VBQ0EsV0FBQTtFQUNBLDJCQUFBO0VBQ0EsWUFBQTtBQUpWO0FBUU07RUFDRSxrQkFBQTtFQUNBLFNBQUE7QUFOUjtBQVlJO0VBQ0UscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esb0NBQUE7RUFHQSxjQUFBO0FBWk47QUFlSTtFQUNFLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFiTjtBQWdCSTtFQUNFLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLHFDQUFBO0VBR0EsY0FBQTtBQWhCTjtBQW1CSTtFQUNFLGlCQUFBO0FBakJOO0FBb0JJOzs7Ozs7RUFNRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQWxCTjtBQXFCSTtFQUNFLGVBQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtBQW5CTjtBQXVCTTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtBQXJCUjtBQXlCSTtFQUNFLHFCQUFBO0VBQ0EsOENBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUF2Qk4iLCJmaWxlIjoiYXNzb2NpYXRlcy1kZXRhaWxzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjo6bmctZGVlcCB7XHJcbiAgYXBwLWFzc29jaWF0ZXMtZGV0YWlscyB7XHJcbiAgICBpb24tcm93IHtcclxuICAgICAgJi5saXN0IHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjRjZGOEZBO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDMxcHggMzFweCAzMXB4IDBweDtcclxuICAgICAgICAvLyBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgLy8gdG9wOiA0M3B4O1xyXG5cclxuICAgICAgICBwLmxpbmUge1xyXG4gICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XHJcbiAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgIG1hcmdpbjogMzhweCAxN3B4IC05cHggMTdweDtcclxuICAgICAgICAgIG9wYWNpdHk6IDAuMztcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5wcm9maWxlLWRldGFpbHMge1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICB0b3A6IDQzcHg7XHJcblxyXG4gICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICAgIC50YWcxIHtcclxuICAgICAgZm9udC1mYW1pbHk6ICdSb2JvdG8nO1xyXG4gICAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDE2cHg7XHJcbiAgICAgIC8qIGlkZW50aWNhbCB0byBib3ggaGVpZ2h0LCBvciA4OSUgKi9cclxuXHJcblxyXG4gICAgICBjb2xvcjogIzMxMzMzRDtcclxuICAgIH1cclxuXHJcbiAgICAudGFnMiB7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcclxuICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgIGxpbmUtaGVpZ2h0OiAxNnB4O1xyXG4gICAgICBjb2xvcjogIzMxMzMzRDtcclxuICAgIH1cclxuXHJcbiAgICAudGFnMyB7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiAnUm9ib3RvJztcclxuICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgIGxpbmUtaGVpZ2h0OiAxNnB4O1xyXG4gICAgICAvKiBpZGVudGljYWwgdG8gYm94IGhlaWdodCwgb3IgMTAwJSAqL1xyXG5cclxuXHJcbiAgICAgIGNvbG9yOiAjMzEzMzNEO1xyXG4gICAgfVxyXG5cclxuICAgIC5saXN0LWhlYWRpbmcge1xyXG4gICAgICBtYXJnaW4tdG9wOiAtMzhweDtcclxuICAgIH1cclxuXHJcbiAgICBoMSxcclxuICAgIGgyLFxyXG4gICAgaDMsXHJcbiAgICBoNCxcclxuICAgIGg1LFxyXG4gICAgaDYge1xyXG4gICAgICBtYXJnaW4tdG9wOiAtMXB4O1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICBsaW5lLWhlaWdodDogMS4yO1xyXG4gICAgfVxyXG5cclxuICAgIC5wcm9maWxlIHtcclxuICAgICAgbWF4LXdpZHRoOiAxMDAlO1xyXG4gICAgICBib3JkZXI6IDA7XHJcbiAgICAgIGhlaWdodDogMTA5cHg7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgdG9wOiA4MXB4O1xyXG4gICAgfVxyXG5cclxuICAgIGlvbi1yb3cge1xyXG4gICAgICAmLm5leHQtYnRuIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOiAxM3JlbTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5jdXN0b20tdGV4dCB7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogI0ZGNEU0RTtcclxuICAgICAgLS1ib3JkZXItcmFkaXVzOiA4M3B4IDYwcHggNjBweCAwcHggIWltcG9ydGFudDtcclxuICAgICAgaGVpZ2h0OiA1NHB4O1xyXG4gICAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 1895:
/*!***********************************************************************************************!*\
  !*** ./src/app/authenticate/pages/associates-details/associates-details.page.html?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-padding-start ion-padding-top ion-padding-end\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n    </ion-buttons>\n    <ion-title>Associate’s Details</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-row>\n    <ion-col class=\"text-center list-heading\">\n      <img class=\"profile\" src=\"./assets/icon/profile.svg\" />\n    </ion-col>\n  </ion-row>\n\n  <ion-row class=\"ion-margin list \">\n    <ion-col size=\"12\" class=\"text-center ion-padding profile-details \">\n      <h1 clas=\"tag1\">Amit Pramanik</h1>\n      <h6 class=\"tag2\">amitpramanik@pharma3.com</h6>\n      <h6 class=\"tag3\">+91 9874 563210 </h6>\n    </ion-col>\n\n    <p class=\"line\"></p>\n\n    <ion-col size=\"12\" class=\"ion-padding\">\n      <p>State: West Bengal</p>\n      <p>City: Kolkata</p>\n      <p>PIN code: 700110</p>\n    </ion-col>\n  </ion-row>\n  <ion-row class=\"next-btn ion-padding-top ion-margin \">\n    <ion-col size=\"12\">\n      <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/assosiates\" class=\"custom-text\">REMOVE ASSOCIATE\n      </ion-button>\n    </ion-col>\n  </ion-row>\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_authenticate_pages_associates-details_associates-details_module_ts.js.map