"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth_pages_login_login_module_ts"],{

/***/ 4754:
/*!**********************************************************!*\
  !*** ./src/app/auth/pages/login/login-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 6488);




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 7694:
/*!**************************************************!*\
  !*** ./src/app/auth/pages/login/login.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 4754);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 6488);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage]
    })
], LoginPageModule);



/***/ }),

/***/ 6488:
/*!************************************************!*\
  !*** ./src/app/auth/pages/login/login.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page.html?ngResource */ 3442);
/* harmony import */ var _login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.scss?ngResource */ 6853);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let LoginPage = class LoginPage {
    constructor() {
        this.showPsw = false;
    }
    ngOnInit() {
    }
    changePassword() {
        console.log(this.showPsw);
        this.showPsw = !this.showPsw;
    }
};
LoginPage.ctorParameters = () => [];
LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-login',
        template: _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LoginPage);



/***/ }),

/***/ 6853:
/*!*************************************************************!*\
  !*** ./src/app/auth/pages/login/login.page.scss?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-login .top-logo {\n  position: relative;\n  margin-top: 2pc;\n}\n::ng-deep app-login .top-logo img {\n  width: 11pc;\n}\n::ng-deep app-login .footer-text {\n  font-size: 14px;\n  color: #BEBEC1;\n  font-weight: normal;\n}\n::ng-deep app-login ion-row.next-btn {\n  position: relative;\n  top: 7pc;\n}\n::ng-deep app-login .password {\n  text-decoration: none;\n}\n::ng-deep app-login .custom-textbox {\n  font-weight: 400;\n  font-size: 14px;\n  line-height: 126.39%;\n  border-radius: 50px 60px 60px 0px;\n}\n::ng-deep app-login .forgot-link a {\n  color: var(--ion-color-primary);\n  text-decoration: none;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFSTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtBQUROO0FBSU07RUFDRSxXQUFBO0FBRlI7QUFNSTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7QUFKTjtBQVFNO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0FBTlI7QUFXSTtFQUNFLHFCQUFBO0FBVE47QUFZSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLG9CQUFBO0VBQ0EsaUNBQUE7QUFWTjtBQWNNO0VBQ0UsK0JBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7QUFaUiIsImZpbGUiOiJsb2dpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6Om5nLWRlZXAge1xyXG4gIGFwcC1sb2dpbiB7XHJcbiAgICAudG9wLWxvZ28ge1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIG1hcmdpbi10b3A6IDJwYztcclxuXHJcbiAgICAgIC8vIHRvcDogNTZweDtcclxuICAgICAgaW1nIHtcclxuICAgICAgICB3aWR0aDogMTFwYztcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5mb290ZXItdGV4dCB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgY29sb3I6ICNCRUJFQzE7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XHJcbiAgICB9XHJcblxyXG4gICAgaW9uLXJvdyB7XHJcbiAgICAgICYubmV4dC1idG4ge1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICB0b3A6IDdwYztcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICAucGFzc3dvcmQge1xyXG4gICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICB9XHJcblxyXG4gICAgLmN1c3RvbS10ZXh0Ym94IHtcclxuICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICBsaW5lLWhlaWdodDogMTI2LjM5JTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogNTBweCA2MHB4IDYwcHggMHB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5mb3Jnb3QtbGluayB7XHJcbiAgICAgIGEge1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICB9XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 3442:
/*!*************************************************************!*\
  !*** ./src/app/auth/pages/login/login.page.html?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <form>\n    <div class=\"login-screen\">\n      <div class=\"text-center top-logo ion-padding ion-margin\">\n        <img src=\"assets/icon/Pharma.png\">\n        <ion-text>\n          <p class=\"tag\">Login for a seamless experience</p>\n        </ion-text>\n      </div>\n      <ion-row lines=\"none\" class=\"ion-margin ion-padding-top\">\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\"\n            placeholder=\"Email address\">\n            <ion-icon [src]=\"'assets/icon/email-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n          </ion-input>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" [type]=\"showPsw ? 'text' : 'password'\" expand=\"block\"\n            class=\"form-control custom-textbox right-icon-available\" placeholder=\"Password\">\n            <ion-icon [src]=\"'assets/icon/lock-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n\n            <ion-icon *ngIf=\"showPsw==true\" (click)=\"changePassword()\" class=\"right-icon\"\n              [src]=\"'assets/icon/pass-eye-close-ico.svg'\" color=\"warning\"></ion-icon>\n            <ion-icon [src]=\"'assets/icon/pass-eye-close-ico.svg'\" (click)=\"changePassword()\" class=\"right-icon\"\n              *ngIf=\"showPsw==false\" color=\"warning\">\n            </ion-icon>\n          </ion-input>\n        </ion-col>\n\n        <ion-col size=\"12\" class=\"ion-margin-bottom text-center forgot-link\">\n          <br>\n          <a href=\"javascript:void(0);\" class=\"password\" routerLink=\"/auth/forgotpassword\">Forgot your password?</a>\n        </ion-col>\n      </ion-row>\n\n\n      <ion-row class=\"next-btn ion-padding-top ion-margin\">\n        <ion-col size=\"12\">\n          <ion-button expand=\"block\" type=\"submit\" routerLink=\"/admin\" class=\"custom-btn\">Next\n          </ion-button>\n        </ion-col>\n        <ion-col class=\"text-center\" size=\"12\">\n          <p class=\"footer-text ion-no-margin\">\n            Don't have an account?\n            <a class=\"password\" routerLink=\"/auth/register\" href=\"javascript:void(0);\">SIGN UP</a>\n          </p>\n        </ion-col>\n        <ion-col class=\"terms-policy\" size=\"12\">\n          <ion-text color=\"medium\" class=\"text-center \">\n            <p class=\"footer-text ion-no-margin\">\n              By Signing in you agree to our <br>\n              <a class=\"password\" href=\"javascript:void(0);\">Terms & conditions</a>\n              and\n              <a class=\"password\" href=\"javascript:void(0);\">Privacy policy</a>\n            </p>\n          </ion-text>\n        </ion-col>\n      </ion-row>\n\n    </div>\n\n  </form>\n\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_auth_pages_login_login_module_ts.js.map