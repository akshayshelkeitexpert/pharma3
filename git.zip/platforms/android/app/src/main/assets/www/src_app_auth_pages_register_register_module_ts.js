"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth_pages_register_register_module_ts"],{

/***/ 3061:
/*!****************************************************************!*\
  !*** ./src/app/auth/pages/register/register-routing.module.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageRoutingModule": () => (/* binding */ RegisterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page */ 8271);




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_0__.RegisterPage
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ 5239:
/*!********************************************************!*\
  !*** ./src/app/auth/pages/register/register.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageModule": () => (/* binding */ RegisterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register-routing.module */ 3061);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page */ 8271);







let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _register_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegisterPageRoutingModule
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_1__.RegisterPage]
    })
], RegisterPageModule);



/***/ }),

/***/ 8271:
/*!******************************************************!*\
  !*** ./src/app/auth/pages/register/register.page.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPage": () => (/* binding */ RegisterPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page.html?ngResource */ 8091);
/* harmony import */ var _register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page.scss?ngResource */ 1833);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let RegisterPage = class RegisterPage {
    constructor() { }
    ngOnInit() {
    }
};
RegisterPage.ctorParameters = () => [];
RegisterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-register',
        template: _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegisterPage);



/***/ }),

/***/ 1833:
/*!*******************************************************************!*\
  !*** ./src/app/auth/pages/register/register.page.scss?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-register .header {\n  top: 38px;\n  position: relative;\n  left: 12px;\n}\n::ng-deep app-register .logo {\n  width: 205px;\n}\n::ng-deep app-register .recover {\n  bottom: 12px;\n  position: relative;\n}\n::ng-deep app-register .recover .tag {\n  font-weight: 400;\n  font-size: 26px;\n}\n::ng-deep app-register .recover .tag2 {\n  font-size: 15px;\n}\n::ng-deep app-register ion-row .custom-textbox {\n  opacity: 0.5;\n  border: 1px solid #000000;\n  box-sizing: border-box;\n  border-radius: 60px;\n  color: #93949A;\n  padding: 7px 9px !important;\n  color: black;\n}\n::ng-deep app-register ion-row.next-btn {\n  position: relative;\n  bottom: 15px;\n}\n::ng-deep app-register ion-row.forgot-btn {\n  position: relative;\n  top: 5rem;\n  text-decoration: none;\n  font-size: 20px;\n}\n::ng-deep app-register .left-icon {\n  margin-left: 10px;\n  padding: 6px;\n}\n::ng-deep .custom {\n  color: #000000;\n  --box-shadow: none;\n  --background: #F6F8FA;\n  border-radius: 7px;\n}\n::ng-deep .footer {\n  font-size: 13px;\n  bottom: 26px;\n  position: relative;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFSTtFQUNFLFNBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUFETjtBQUlJO0VBQ0UsWUFBQTtBQUZOO0FBS0k7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7QUFITjtBQUtNO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0FBSFI7QUFNTTtFQUNFLGVBQUE7QUFKUjtBQWlCTTtFQUNFLFlBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7RUFFQSxZQUFBO0FBaEJSO0FBbUJNO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0FBakJSO0FBb0JNO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0FBbEJSO0FBd0JJO0VBQ0UsaUJBQUE7RUFDQSxZQUFBO0FBdEJOO0FBMkJFO0VBSUUsY0FBQTtFQUNBLGtCQUFBO0VBRUEscUJBQUE7RUFDQSxrQkFBQTtBQTdCSjtBQW9DRTtFQUNFLGVBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFsQ0oiLCJmaWxlIjoicmVnaXN0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIHtcclxuICBhcHAtcmVnaXN0ZXIge1xyXG4gICAgLmhlYWRlciB7XHJcbiAgICAgIHRvcDogMzhweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICBsZWZ0OiAxMnB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5sb2dvIHtcclxuICAgICAgd2lkdGg6IDIwNXB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5yZWNvdmVyIHtcclxuICAgICAgYm90dG9tOiAxMnB4O1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgICAudGFnIHtcclxuICAgICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjZweDtcclxuICAgICAgfVxyXG5cclxuICAgICAgLnRhZzIge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcblxyXG4gICAgLy8gLmlucHV0IHtcclxuICAgIC8vICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgLy8gICBib3R0b206IDE1cHg7XHJcbiAgICAvLyB9XHJcblxyXG5cclxuICAgIGlvbi1yb3cge1xyXG4gICAgICAuY3VzdG9tLXRleHRib3gge1xyXG4gICAgICAgIG9wYWNpdHk6IDAuNTtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjMDAwMDAwO1xyXG4gICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNjBweDtcclxuICAgICAgICBjb2xvcjogIzkzOTQ5QTtcclxuICAgICAgICBwYWRkaW5nOiA3cHggOXB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgLy8gbWFyZ2luLWxlZnQ6IDEycHggIWltcG9ydGFudDtcclxuICAgICAgICBjb2xvcjogYmxhY2s7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgICYubmV4dC1idG4ge1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICBib3R0b206IDE1cHg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgICYuZm9yZ290LWJ0biB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHRvcDogNXJlbTtcclxuICAgICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLm1lbnVsLXRleHRib3gge31cclxuXHJcbiAgICAubGVmdC1pY29uIHtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICAgIHBhZGRpbmc6IDZweDtcclxuICAgIH1cclxuXHJcbiAgfVxyXG5cclxuICAuY3VzdG9tIHtcclxuXHJcblxyXG5cclxuICAgIGNvbG9yOiAjMDAwMDAwO1xyXG4gICAgLS1ib3gtc2hhZG93OiBub25lO1xyXG5cclxuICAgIC0tYmFja2dyb3VuZDogI0Y2RjhGQTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDdweDtcclxuICB9XHJcblxyXG4gIC8vIGlvbi1mb290ZXIge1xyXG4gIC8vICAgcG9zaXRpb246IGZpeGVkO1xyXG4gIC8vICAgYm90dG9tOiAwcHg7XHJcbiAgLy8gfVxyXG4gIC5mb290ZXIge1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgYm90dG9tOiAyNnB4O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIH1cclxufVxyXG4iXX0= */";

/***/ }),

/***/ 8091:
/*!*******************************************************************!*\
  !*** ./src/app/auth/pages/register/register.page.html?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <form>\n    <div class=\"login-screen\">\n      <div class=\"text-center top-logo ion-padding ion-margin\">\n        <img src=\"assets/icon/Pharma.png\">\n        <ion-text>\n          <p class=\"tag\">Login for a seamless experience</p>\n        </ion-text>\n      </div>\n      <ion-row lines=\"none\" class=\"ion-margin ion-padding-top\">\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\"\n            placeholder=\"Company Name\">\n            <ion-icon [src]=\"'assets/icon/email-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n          </ion-input>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\"\n            placeholder=\"Email Address\">\n            <ion-icon [src]=\"'assets/icon/email-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n          </ion-input>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" type=\"text\" expand=\"block\" class=\"form-control custom-textbox\"\n            placeholder=\"Mobile Number\">\n            <ion-icon [src]=\"'assets/icon/email-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n          </ion-input>\n        </ion-col>\n\n\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" [type]=\"showPsw ? 'text' : 'password'\" expand=\"block\"\n            class=\"form-control custom-textbox right-icon-available\" placeholder=\"Password\">\n            <ion-icon [src]=\"'assets/icon/lock-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n\n            <ion-icon *ngIf=\"showPsw==true\" (click)=\"changePassword()\" class=\"right-icon\"\n              [src]=\"'assets/icon/pass-eye-close-ico.svg'\" color=\"warning\"></ion-icon>\n            <ion-icon [src]=\"'assets/icon/pass-eye-close-ico.svg'\" (click)=\"changePassword()\" class=\"right-icon\"\n              *ngIf=\"showPsw==false\" color=\"warning\">\n            </ion-icon>\n          </ion-input>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" [type]=\"showPsw ? 'text' : 'password'\" expand=\"block\"\n            class=\"form-control custom-textbox right-icon-available\" placeholder=\"Password\">\n            <ion-icon [src]=\"'assets/icon/lock-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n\n            <ion-icon *ngIf=\"showPsw==true\" (click)=\"changePassword()\" class=\"right-icon\"\n              [src]=\"'assets/icon/pass-eye-close-ico.svg'\" color=\"warning\"></ion-icon>\n            <ion-icon [src]=\"'assets/icon/pass-eye-close-ico.svg'\" (click)=\"changePassword()\" class=\"right-icon\"\n              *ngIf=\"showPsw==false\" color=\"warning\">\n            </ion-icon>\n          </ion-input>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-input autocomplete=\"off\" [type]=\"showPsw ? 'text' : 'password'\" expand=\"block\"\n            class=\"form-control custom-textbox right-icon-available\" placeholder=\"Password\">\n            <ion-icon [src]=\"'assets/icon/lock-ico.svg'\" class=\"left-icon\" item-left></ion-icon>\n\n            <ion-icon *ngIf=\"showPsw==true\" (click)=\"changePassword()\" class=\"right-icon\"\n              [src]=\"'assets/icon/pass-eye-close-ico.svg'\" color=\"warning\"></ion-icon>\n            <ion-icon [src]=\"'assets/icon/pass-eye-close-ico.svg'\" (click)=\"changePassword()\" class=\"right-icon\"\n              *ngIf=\"showPsw==false\" color=\"warning\">\n            </ion-icon>\n          </ion-input>\n        </ion-col>\n\n      </ion-row>\n      <ion-row class=\"ion-margin\">\n        <ion-col size=\"12\" class=\" forgot-link\">\n          <p>Licenses and Documents </p>\n        </ion-col>\n        <ion-col size=\"7\">\n          <p>Drug License</p>\n        </ion-col>\n        <ion-col size=\"5\">\n          <ion-button expand=\"block\" type=\"submit\" class=\"custom\">\n            <ion-icon [src]=\"'assets/icon/lock-ico.svg'\"></ion-icon>Upload\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"7\">\n          <p>GST Certificate</p>\n        </ion-col>\n        <ion-col size=\"5\">\n          <ion-button expand=\"block\" type=\"submit\" class=\"custom\">\n            <ion-icon [src]=\"'assets/icon/lock-ico.svg'\"></ion-icon>Upload\n\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"7\">\n          <p>FSSAI License</p>\n        </ion-col>\n        <ion-col size=\"5\">\n          <ion-button expand=\"block\" type=\"submit\" class=\"custom\">\n            <ion-icon [src]=\"'assets/icon/lock-ico.svg'\"></ion-icon>Upload\n\n          </ion-button>\n        </ion-col>\n\n        <ion-col size=\"7\">\n          <p>PAN Number</p>\n        </ion-col>\n        <ion-col size=\"5\">\n          <ion-button expand=\"block\" type=\"submit\" class=\"custom\">\n            <ion-icon [src]=\"'assets/icon/lock-ico.svg'\"></ion-icon>Upload\n\n          </ion-button>\n        </ion-col>\n\n\n        <ion-col size=\"7\">\n          <p>Bank Account Details</p>\n        </ion-col>\n        <ion-col size=\"5\">\n          <ion-button expand=\"block\" type=\"submit\" class=\"custom\">\n            <ion-icon [src]=\"'assets/icon/lock-ico.svg'\"></ion-icon>Upload\n\n          </ion-button>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"next-btn ion-padding-top ion-margin \">\n        <ion-col size=\"12\">\n          <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/otp\" class=\"custom-btn\">Next\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"12\" class=\"text-center forgot-link\">\n          <p class=\"footer-text\">\n            Already have an account?\n            <a> LOGIN</a>\n          </p>\n        </ion-col>\n        <ion-col size=\"12\">\n          <ion-text color=\"medium\" class=\"text-center \">\n            <p class=\"footer\">\n              By Signing in you agree to our\n              <a class=\"password\" href=\"javascript:void(0);\">Terms & conditions</a>\n              and\n              <a class=\"password\" href=\"javascript:void(0);\">Privacy policy</a>\n            </p>\n          </ion-text>\n        </ion-col>\n      </ion-row>\n\n    </div>\n\n  </form>\n\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_auth_pages_register_register_module_ts.js.map