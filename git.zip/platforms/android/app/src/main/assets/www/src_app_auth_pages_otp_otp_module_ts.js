"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth_pages_otp_otp_module_ts"],{

/***/ 4903:
/*!******************************************************!*\
  !*** ./src/app/auth/pages/otp/otp-routing.module.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OtpPageRoutingModule": () => (/* binding */ OtpPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _otp_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./otp.page */ 6481);




const routes = [
    {
        path: '',
        component: _otp_page__WEBPACK_IMPORTED_MODULE_0__.OtpPage
    }
];
let OtpPageRoutingModule = class OtpPageRoutingModule {
};
OtpPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], OtpPageRoutingModule);



/***/ }),

/***/ 5370:
/*!**********************************************!*\
  !*** ./src/app/auth/pages/otp/otp.module.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OtpPageModule": () => (/* binding */ OtpPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _otp_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./otp-routing.module */ 4903);
/* harmony import */ var _otp_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./otp.page */ 6481);







let OtpPageModule = class OtpPageModule {
};
OtpPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _otp_routing_module__WEBPACK_IMPORTED_MODULE_0__.OtpPageRoutingModule
        ],
        declarations: [_otp_page__WEBPACK_IMPORTED_MODULE_1__.OtpPage]
    })
], OtpPageModule);



/***/ }),

/***/ 6481:
/*!********************************************!*\
  !*** ./src/app/auth/pages/otp/otp.page.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OtpPage": () => (/* binding */ OtpPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _otp_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./otp.page.html?ngResource */ 5227);
/* harmony import */ var _otp_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./otp.page.scss?ngResource */ 110);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let OtpPage = class OtpPage {
    constructor() { }
    ngOnInit() {
    }
};
OtpPage.ctorParameters = () => [];
OtpPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-otp',
        template: _otp_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_otp_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], OtpPage);



/***/ }),

/***/ 110:
/*!*********************************************************!*\
  !*** ./src/app/auth/pages/otp/otp.page.scss?ngResource ***!
  \*********************************************************/
/***/ ((module) => {

module.exports = "::ng-deep app-otp .header {\n  top: 38px;\n  position: relative;\n  left: 12px;\n}\n::ng-deep app-otp .recover .tag {\n  font-weight: 400;\n  font-size: 26px;\n}\n::ng-deep app-otp .recover .tag2 {\n  font-size: 15px;\n}\n::ng-deep app-otp ion-row .custom-textbox {\n  opacity: 0.5;\n  border: 1px solid #000000;\n  box-sizing: border-box;\n  border-radius: 60px;\n  color: #93949A;\n  padding: 7px 9px !important;\n  color: black;\n}\n::ng-deep app-otp ion-row.next-btn {\n  bottom: 11px;\n  width: 92%;\n}\n::ng-deep app-otp ion-row.forgot-btn {\n  position: relative;\n  top: 5rem;\n  text-decoration: none;\n  font-size: 20px;\n}\n::ng-deep app-otp ion-row .userInput input {\n  background: #F6F8FA;\n  border: none;\n  border-radius: 5px;\n  width: 40px;\n  height: 40px;\n  margin-right: 15px;\n  padding: 0px;\n  text-align: center;\n  font-size: 14px;\n  transition: 0.3s ease-in-out;\n}\n::ng-deep app-otp .left-icon {\n  margin-left: 10px;\n  padding: 6px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm90cC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUk7RUFDRSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FBRE47QUFZTTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtBQVZSO0FBYU07RUFDRSxlQUFBO0FBWFI7QUF3Qk07RUFDRSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0VBRUEsWUFBQTtBQXZCUjtBQTBCTTtFQUVFLFlBQUE7RUFDQSxVQUFBO0FBekJSO0FBNEJNO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0FBMUJSO0FBOEJRO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLDRCQUFBO0FBNUJWO0FBbUNJO0VBQ0UsaUJBQUE7RUFDQSxZQUFBO0FBakNOIiwiZmlsZSI6Im90cC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6Om5nLWRlZXAge1xyXG4gIGFwcC1vdHAge1xyXG4gICAgLmhlYWRlciB7XHJcbiAgICAgIHRvcDogMzhweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICBsZWZ0OiAxMnB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5sb2dvIHtcclxuICAgICAgLy8gd2lkdGg6IDIwNXB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5yZWNvdmVyIHtcclxuICAgICAgLy8gYm90dG9tOiAtMzFweDtcclxuICAgICAgLy8gcG9zaXRpb246IHJlbGF0aXZlO1xyXG5cclxuICAgICAgLnRhZyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgICBmb250LXNpemU6IDI2cHg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC50YWcyIHtcclxuICAgICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG5cclxuICAgIC8vIC5pbnB1dCB7XHJcbiAgICAvLyAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIC8vICAgYm90dG9tOiAxNXB4O1xyXG4gICAgLy8gfVxyXG5cclxuXHJcbiAgICBpb24tcm93IHtcclxuICAgICAgLmN1c3RvbS10ZXh0Ym94IHtcclxuICAgICAgICBvcGFjaXR5OiAwLjU7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgIzAwMDAwMDtcclxuICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDYwcHg7XHJcbiAgICAgICAgY29sb3I6ICM5Mzk0OUE7XHJcbiAgICAgICAgcGFkZGluZzogN3B4IDlweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIC8vIG1hcmdpbi1sZWZ0OiAxMnB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgY29sb3I6IGJsYWNrO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAmLm5leHQtYnRuIHtcclxuICAgICAgICAvLyBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgYm90dG9tOiAxMXB4O1xyXG4gICAgICAgIHdpZHRoOiA5MiU7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgICYuZm9yZ290LWJ0biB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHRvcDogNXJlbTtcclxuICAgICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAudXNlcklucHV0IHtcclxuICAgICAgICBpbnB1dCB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjRjZGOEZBO1xyXG4gICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICAgICAgd2lkdGg6IDQwcHg7XHJcbiAgICAgICAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDE1cHg7XHJcbiAgICAgICAgICBwYWRkaW5nOiAwcHg7XHJcbiAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgICB0cmFuc2l0aW9uOiAwLjNzIGVhc2UtaW4tb3V0O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5tZW51bC10ZXh0Ym94IHt9XHJcblxyXG4gICAgLmxlZnQtaWNvbiB7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gICAgICBwYWRkaW5nOiA2cHg7XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcbiAgLy8gaW9uLWZvb3RlciB7XHJcbiAgLy8gICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgLy8gICBib3R0b206IDBweDtcclxuICAvLyB9XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 5227:
/*!*********************************************************!*\
  !*** ./src/app/auth/pages/otp/otp.page.html?ngResource ***!
  \*********************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <form>\n    <div>\n      <div class=\"header\">\n        <ng-container>\n          <ion-icon name=\"chevron-back-sharp\" class=\"back-arrow\"></ion-icon>\n        </ng-container>\n      </div>\n      <ion-row class=\"ion-margin\">\n        <ion-col size=\"12\" class=\"text-center\">\n          <img [src]=\"'assets/icon/otp-ico.svg'\" class=\"logo\">\n        </ion-col>\n        <ion-col size=\"12\" class=\"text-center\">\n          <br><br>\n          <ion-text class=\"recover\">\n            <h1 class=\"tag\">Enter OTP</h1>\n            <h6 class=\"tag2\">Please enter the number code<br> send your xxx@company.com</h6>\n          </ion-text>\n        </ion-col>\n        <ion-col size=\"12\" class=\"text-center\">\n          <br><br>\n          <div class=\"userInput\">\n            <input type=\"text\" id=\"ist\" maxlength=\"1\">\n            <input type=\"text\" id=\"sec\" maxlength=\"1\">\n            <input type=\"text\" id=\"third\" maxlength=\"1\">\n            <input type=\"text\" id=\"fourth\" maxlength=\"1\">\n          </div>\n        </ion-col>\n      </ion-row>\n\n\n    </div>\n  </form>\n\n</ion-content>\n<ion-footer class=\"ion-no-border\">\n  <ion-row class=\"next-btn ion-padding-top ion-margin \">\n    <ion-col size=\"12\">\n      <ion-button expand=\"block\" type=\"submit\" routerLink=\"/auth/selection\" class=\"custom-btn\">CONFIRM\n      </ion-button>\n    </ion-col>\n  </ion-row>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_auth_pages_otp_otp_module_ts.js.map