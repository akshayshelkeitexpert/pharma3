import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assosiates',
  templateUrl: './assosiates.page.html',
  styleUrls: ['./assosiates.page.scss'],
})
export class AssosiatesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
