import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-associates-details',
  templateUrl: './associates-details.page.html',
  styleUrls: ['./associates-details.page.scss'],
})
export class AssociatesDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
