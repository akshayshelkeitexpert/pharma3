import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reply-quotation',
  templateUrl: './reply-quotation.page.html',
  styleUrls: ['./reply-quotation.page.scss'],
})
export class ReplyQuotationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
