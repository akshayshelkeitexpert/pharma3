import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offersone',
  templateUrl: './offersone.page.html',
  styleUrls: ['./offersone.page.scss'],
})
export class OffersonePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
