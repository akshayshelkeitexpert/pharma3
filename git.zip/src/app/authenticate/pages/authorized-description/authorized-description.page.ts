import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authorized-description',
  templateUrl: './authorized-description.page.html',
  styleUrls: ['./authorized-description.page.scss'],
})
export class AuthorizedDescriptionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
