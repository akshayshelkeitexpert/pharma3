import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quote-notification',
  templateUrl: './quote-notification.page.html',
  styleUrls: ['./quote-notification.page.scss'],
})
export class QuoteNotificationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
