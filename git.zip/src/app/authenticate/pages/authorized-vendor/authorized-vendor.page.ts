import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authorized-vendor',
  templateUrl: './authorized-vendor.page.html',
  styleUrls: ['./authorized-vendor.page.scss'],
})
export class AuthorizedVendorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
