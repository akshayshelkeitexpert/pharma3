import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-document-view',
  templateUrl: './document-view.page.html',
  styleUrls: ['./document-view.page.scss'],
})
export class DocumentViewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
