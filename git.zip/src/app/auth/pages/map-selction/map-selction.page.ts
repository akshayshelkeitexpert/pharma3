import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-map-selction',
  templateUrl: './map-selction.page.html',
  styleUrls: ['./map-selction.page.scss'],
})
export class MapSelctionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
