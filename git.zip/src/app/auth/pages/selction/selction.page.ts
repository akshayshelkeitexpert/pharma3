import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selction',
  templateUrl: './selction.page.html',
  styleUrls: ['./selction.page.scss'],
})
export class SelctionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
